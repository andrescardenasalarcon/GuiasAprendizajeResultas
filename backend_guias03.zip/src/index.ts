import Server from "./configuration/api/Server";

const server = new Server();
server.start();