export default {
    user: 'user_angular',
    host: 'localhost',
    database: 'bd_angular_guias003',
    password: '123456',
    port: 5432
}