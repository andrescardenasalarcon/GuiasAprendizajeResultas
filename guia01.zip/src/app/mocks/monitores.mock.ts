import { Monitor } from "../modelos/monitor.model";

export const ARRAY_MONITORES: Array<Monitor> = [
    new Monitor(1,"Seleccione un monitor"),
    new Monitor(2,"ASUS", 34),
    new Monitor(3,"LENOVO", 32),
    new Monitor(4,"AORUS", 24),
    new Monitor(5,"SAMNSUNG", 42)
]
