import { Monitor } from "./monitor.model";
import { Raton } from "./raton.model";
import { Teclado } from "./teclado.model";

export class Computador {
    public idComputador: number;
    public nombre: String;
    public monitor: Monitor;
    public raton: Raton;
    public teclado: Teclado;

    constructor(idComputador: number, nombre: String, monitor: Monitor, raton: Raton, teclado: Teclado) {
        this.idComputador = idComputador;
        this.nombre = nombre;
        this.monitor = monitor;
        this.raton = raton;
        this.teclado = teclado;

    }

}
