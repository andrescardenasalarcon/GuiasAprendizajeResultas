import { DispositivoEntrada } from "./dispositivo-entrada.model";

export class Raton extends DispositivoEntrada {
    public id: number;
    
    constructor(id: number,DispositivoEntrada: String, Marca: String) {
        super(DispositivoEntrada, Marca);
        this.id = id;
        
    }

}
