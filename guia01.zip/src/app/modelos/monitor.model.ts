export class Monitor{
    public idMonitor: number;
    public marca : String;
    public tamanno? : number;

    constructor(id: number,marca: String, tamanno?: number) {
        this.marca = marca;
        this.tamanno = tamanno;
        this.idMonitor = id;   
    }
}
