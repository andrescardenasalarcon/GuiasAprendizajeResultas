export class DispositivoEntrada {
    public dispositivoEntrada: String;
    public marca: String;

    constructor(DispositivoEntrada: String, Marca: String) {
        this.dispositivoEntrada = DispositivoEntrada;
        this.marca = Marca;
    }
}
