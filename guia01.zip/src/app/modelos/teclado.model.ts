import { DispositivoEntrada } from "./dispositivo-entrada.model";

export class Teclado extends DispositivoEntrada {
    public id: number;
    
    constructor(id: number, DispositivoEntrada: String, Marca: String) {
        super(DispositivoEntrada, Marca);
        this.id = id;
    }

}
