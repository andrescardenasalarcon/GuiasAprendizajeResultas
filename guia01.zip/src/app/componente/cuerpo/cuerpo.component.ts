import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Monitor } from '../../modelos/monitor.model';
import { Raton } from '../../modelos/raton.model';
import { Teclado } from '../../modelos/teclado.model';
import { Computador } from '../../modelos/computador.model';
import { ARRAY_MONITORES } from '../../mocks/monitores.mock';
import { ARRAY_RATONES } from '../../mocks/ratones.mock';
import { ARRAY_TECLADOS } from '../../mocks/teclados.mock';
import { ARREGLO_PC } from '../../mocks/computadores.mock';

@Component({
  selector: 'app-cuerpo',
  templateUrl: './cuerpo.component.html',
  styleUrl: './cuerpo.component.css'
})
export class CuerpoComponent implements OnInit {
  // Creación de los Parametros
  public titulo: string = '';

  //Monitor
  public arregloMonitor: Monitor[];
  //Raton
  public arregloRaton: Raton[];
  public ratonSeleccionado: Raton;
  //Teclado
  public arregloTeclado: Teclado[];
  public tecladoSeleccionado: Teclado;
  //Computador
  public arregloPc: Computador[];
  public pcSeleccionado: Computador;

  //Parametro objeto que recibe Objetos de tipo Raton o Teclado
  public objetoSeleccionado: Raton | Teclado;

  // Parametro bandera para combobox
  public esRatonTeclado: boolean;

  // Inicialización parámetros en el constructor
  constructor() {
    this.titulo = "Ratón";

    this.arregloMonitor = ARRAY_MONITORES;
    this.arregloRaton = ARRAY_RATONES;
    this.arregloTeclado = ARRAY_TECLADOS;
    this.arregloPc = ARREGLO_PC;
    this.ratonSeleccionado = this.inicializarRaton();
    this.tecladoSeleccionado = this.inicializarTeclado();
    this.pcSeleccionado = this.inicializarPc();

    this.objetoSeleccionado = this.inicializarRaton();
    this.esRatonTeclado = true;
  }
  //*********Inicio de la lógica CRUD para un computador*********
  ngOnInit(): void {
    this.inicializarCombo();
  }

  public inicializarCombo(): void {
    this.pcSeleccionado.monitor = ARRAY_MONITORES[0];
    this.pcSeleccionado.teclado = ARRAY_TECLADOS[0];
    this.pcSeleccionado.raton = ARRAY_RATONES[0];
  }

  //Logica de negocio 
  public seleccionarPc(pc: Computador): void {
    // Utiliza Object.assign() para crear una copia del objeto seleccionado
    this.pcSeleccionado = { ...pc };
  }

  public eliminarPc(del: Computador): void {
    if (confirm(`¿En realidad desea eliminar el Computador ${del.nombre}?`)) {
      this.arregloPc = this.arregloPc.filter((mipc) => mipc !== del);
    }
  }


  public seleccionarRaton(ra: Raton): void {
    this.ratonSeleccionado = { ...ra };
    this.objetoSeleccionado = ra;
    this.esRatonTeclado = true;
    this.titulo = "Ratón";

  }

  public seleccionarTeclado(te: Teclado): void {
    this.tecladoSeleccionado = { ...te };
    this.objetoSeleccionado = te;
    this.esRatonTeclado = false;
    this.titulo = "Teclado";
  }
  //Lógica para el formulario Computador
  public operaciones(form: NgForm, event: any): void {
    const accion = event.submitter.id;

    switch (accion) {
      case "btnCrearPc":
        this.crearPc(form);
        break;
      case "btnActualizarPc":
        this.actualizarPc(form);
        break;
    }
  }
  public crearPc(form: NgForm): void {
    if (form.valid) {
      this.pcSeleccionado.idComputador = this.arregloPc.length + 1;
      this.arregloPc.push(this.pcSeleccionado);
      this.cancelForm(form);
    }
  }

  public actualizarPc(form: NgForm): void {
    if (form.valid) {
      const index = this.arregloPc.findIndex(pc => pc.idComputador === this.pcSeleccionado.idComputador);
      if (index !== -1) {
        this.arregloPc[index] = this.pcSeleccionado = { ...this.pcSeleccionado };
      }
      this.cancelForm(form)
    }
  }

  public cancelForm(form: NgForm): void {
    this.resetPc();
    form.resetForm();
    this.inicializarCombo();
  }

  public resetPc(): void {
    this.pcSeleccionado = this.inicializarPc();
  }

  //**********Fin de la lógica CRUD para un computador**********



  //**********Inicio de la lógica CRUD para los Ratones y Teclado**********
  public operacionesPerifericos(form: NgForm, event: any): void {
    const accion = event.submitter.id

    switch (accion) {
      case "crearPeriferico":
        this.creacionPerifericos(form);
        break;
      case "actualizarPeriferico":
        this.actualizacionPerifericos(form);
        break;
    }
  }
  public creacionPerifericos(form: NgForm): void {
    if (this.esRatonTeclado === true) {
      this.crearRaton(form);
    } else {
      this.crearTeclado(form);

    }
  }
  public actualizacionPerifericos(form: NgForm): void {
    if (this.esRatonTeclado === true) {
      this.actualizarRaton(form);
    } else {
      this.actualizarTeclado(form);
    }
  }
  public crearRaton(form: NgForm): void {

    if (form.valid) {
      this.ratonSeleccionado.id = this.arregloRaton.length + 1;
      this.arregloRaton.push(this.ratonSeleccionado);
      this.resetRaton();
      form.reset();
      this.inicializarCombo();
    }
  }
  public crearTeclado(form: NgForm): void {
    if (form.valid) {
      this.tecladoSeleccionado.id = this.arregloTeclado.length + 1;
      this.arregloTeclado.push(this.tecladoSeleccionado);
      this.resetTeclado();
      form.reset();
      this.inicializarCombo();
    }
  }
  public actualizarRaton(form: NgForm): void {
    if (form.valid) {
      const index = this.arregloRaton.findIndex(ra => ra.id === this.ratonSeleccionado.id);
      if (index !== -1) {
        this.arregloRaton[index] = this.ratonSeleccionado = { ...this.ratonSeleccionado };
      }
      this.resetRaton();
      form.resetForm();
    }
  }

  public actualizarTeclado(form: NgForm): void {
    if (form.valid) {
      const index = this.arregloTeclado.findIndex(te => te.id === this.tecladoSeleccionado.id);
      if (index !== -1) {
        this.arregloTeclado[index] = this.tecladoSeleccionado = { ...this.tecladoSeleccionado };
      }
      this.resetTeclado();
      form.resetForm();
    }
  }

  public deletePeriferico(): void {
    if (confirm(`¿En realidad desea eliminar el periferico ${this.objetoSeleccionado?.marca}?`)) {
      if (this.objetoSeleccionado instanceof Raton) {
        this.arregloRaton = this.arregloRaton.filter((objRaton) => objRaton != this.objetoSeleccionado);
        this.resetRaton();
      } else {
        this.arregloTeclado = this.arregloTeclado.filter((objTeclado) => objTeclado != this.objetoSeleccionado);
        this.resetTeclado();
      }
    }
  }
  public tipoPeriferico(rate: boolean): void {
    this.esRatonTeclado = rate;
    this.esRatonTeclado ? this.titulo = "Ratón" : this.titulo = "Teclado";

  }
  public cancelFormPerifericos(form: NgForm): void {
    this.objetoSeleccionado = this.inicializarRaton();
    this.resetRaton();
    this.resetTeclado();
  }
  public resetRaton(): void {
    this.ratonSeleccionado = this.inicializarRaton();
    this.objetoSeleccionado = this.inicializarRaton()
  }

  public resetTeclado(): void {
    this.tecladoSeleccionado = this.inicializarTeclado();
    this.objetoSeleccionado = this.inicializarTeclado();
  }

  //**********Fin de la logia CRUD para los periféricos**********
  // Inicialización de Clases
  public inicializarPc(): Computador {
    return new Computador(0, "", new Monitor(0, "", 0), new Raton(0, "", "",), new Teclado(0, "", ""));
  }
  public inicializarRaton(): Raton {
    return new Raton(0, "", "",);
  }
  public inicializarTeclado(): Teclado {
    return new Teclado(0, "", "");
  }
}
