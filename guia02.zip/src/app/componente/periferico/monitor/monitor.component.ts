import { Component, TemplateRef } from '@angular/core';
import { Monitor } from '../../../modelos/monitor.model';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ARRAY_MONITORES } from '../../../mocks/monitores.mock';
import * as globals from '../../../utilidades/globals/inits.func';

@Component({
  selector: 'app-monitor',
  templateUrl: './monitor.component.html',
  styleUrl: './monitor.component.css'
})
export class MonitorComponent {
  public arregloMonitor: Monitor[];
  public monitorSeleccionado: Monitor;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;

  constructor(public misRutas: Router, public miModal: BsModalService) {
    this.arregloMonitor = ARRAY_MONITORES;
    this.monitorSeleccionado = globals.inicializarMonitor();

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }

  public seleccionarMonitor(mo: Monitor): void {
  }

  public eliminarMonitor(del: Monitor): void {
    
  }

  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarMonitor(this.monitorSeleccionado);
    this.btnCancelar();
  }

  public btnCancelar(): void {
    this.modalRef.hide();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Monitor): void {
    this.monitorSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Monitor?"
    this.modalContenido = `${obj.toString()}`;
    this.modalContenidoImg = obj.base64Monitor;
  }
}


