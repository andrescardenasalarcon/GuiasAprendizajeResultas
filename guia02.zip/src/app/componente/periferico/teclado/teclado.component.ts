import { Component, TemplateRef } from '@angular/core';
import { Teclado } from '../../../modelos/teclado.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ARRAY_TECLADOS } from '../../../mocks/teclados.mock';
import * as globals from '../../../utilidades/globals/inits.func';

@Component({
  selector: 'app-teclado',
  templateUrl: './teclado.component.html',
  styleUrl: './teclado.component.css'
})
export class TecladoComponent {
  public tecladoSeleccionado: Teclado;
  public arregloTeclado: Teclado[];

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;


  constructor(public misRutas: Router, public miModal: BsModalService) {
    this.arregloTeclado = ARRAY_TECLADOS;
    this.tecladoSeleccionado = globals.inicializarTeclado();

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }

  public seleccionarTeclado(te: Teclado): void {
    this.tecladoSeleccionado = te
    this.misRutas.navigate(['/dash/keyboard/detail', te.id]);

  }

  public eliminarTeclado(del: Teclado): void {
    let pos: number = 0;
    this.arregloTeclado.forEach((dato, indice, arregloFn) => {
      if (arregloFn[indice] === del) {
        pos = indice;
      }
    });
    this.arregloTeclado.splice(pos, 1);
  }

  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarTeclado(this.tecladoSeleccionado);
    this.btnCancelar();
    this.misRutas.navigate(['/dash/keyboard']);
  }

  public btnCancelar(): void {
    this.modalRef.hide();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Teclado): void {
    this.tecladoSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Teclado?"
    this.modalContenido = `Marca: ${this.tecladoSeleccionado.marca}, Dispositivo de Entrada: ${this.tecladoSeleccionado.dispositivoEntrada}`;
  }
}
