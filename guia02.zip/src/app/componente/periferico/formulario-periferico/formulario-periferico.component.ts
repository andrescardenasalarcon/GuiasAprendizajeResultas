import { Component, OnInit } from '@angular/core';
import { Raton } from '../../../modelos/raton.model';
import { Teclado } from '../../../modelos/teclado.model';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import { ARRAY_RATONES } from '../../../mocks/ratones.mock';
import { ARRAY_TECLADOS } from '../../../mocks/teclados.mock';
import * as globals from '../../../utilidades/globals/inits.func';

@Component({
  selector: 'app-formulario-periferico',
  templateUrl: './formulario-periferico.component.html',
  styleUrl: './formulario-periferico.component.css'
})
export class FormularioPerifericoComponent{
  public titulo: string = '';
  public arregloRaton: Raton[];
  public arregloTeclado: Teclado[];
  public objetoSeleccionado: Raton | Teclado;


  constructor(private route: ActivatedRoute, private misRutas: Router, public toastr: ToastrService) {
    this.arregloRaton = ARRAY_RATONES;
    this.arregloTeclado = ARRAY_TECLADOS;
    this.objetoSeleccionado = globals.inicializarRaton();
    this.urlTitle();

  }

  public urlTitle(): void {
    const url = this.misRutas.url;
    this.titulo = url.includes('mouse') ? 'Ratón' : 'Teclado';
    if (url.includes('mouse')) {
      this.objetoSeleccionado = globals.inicializarRaton();
    } else {
      this.objetoSeleccionado = globals.inicializarTeclado();
    }
    this.cargarPeriferico();
  };

  public cargarPeriferico(): void {
    this.route.paramMap.subscribe((parametro: ParamMap) => {
      const dato = String(parametro.get("codP"));
      const numero = parseInt(dato);

      if (this.objetoSeleccionado instanceof Raton) {
        this.arregloRaton.find((r) => {
          if (r.id === numero) {
            this.objetoSeleccionado = {...r};
          }
        });

      } else {
        this.arregloTeclado.find((t) => {
          if (t.id === numero) {
            this.objetoSeleccionado = t;
          }
        });
      }
    }
    );
  }

  public operacionesPerifericos(form: NgForm, event: any): void {
    const accion = event.submitter.id;
    
    switch (accion) {
      case "crearPeriferico":
        this.crearPeriferico(form);
        break;
      case "actualizarPeriferico":
        this.actualizacionPerifericos(form);
        break;
    }
  }


  public generarGenerico<A extends Raton | Teclado>(p: A[], obj: A): void {
    p.push(obj);
  };

  public crearPeriferico(form: NgForm): void {
    if (form.valid) {
      if (this.objetoSeleccionado instanceof Raton) {
        this.crearRaton();
      } else {
        this.crearTeclado();
      }
      form.resetForm();
    } else {
      mostrarMensaje("error", "No se pueden crear Perifericos<br />con campos vacíos", "Advertencia", this.toastr);

    }
  }
  public actualizacionPerifericos(form: NgForm): void {
    if (this.objetoSeleccionado instanceof Raton) {
      this.actualizarRaton(form);
    } else {
      this.actualizarTeclado(form);

    }

  }
  public crearRaton(): void {
    this.objetoSeleccionado.id = this.arregloRaton.length + 1;
    this.generarGenerico(this.arregloRaton, this.objetoSeleccionado);
    mostrarMensaje('success', `Nuevo Periferico de tipo Ratón Creado!`, 'Añadido', this.toastr);
    this.resetRaton();

  }

  public crearTeclado(): void {
    this.objetoSeleccionado.id = this.arregloTeclado.length + 1;
    this.generarGenerico(this.arregloTeclado, this.objetoSeleccionado);
    mostrarMensaje('success', `Nuevo Periferico de tipo Teclado Creado!`, 'Añadido', this.toastr);
    this.resetTeclado();
  }

  public actualizarPeriferico<T extends Raton | Teclado>(index: number, arrayObj: T[], obj: T): void {
    arrayObj[index] = obj;
  }

  public actualizarRaton(form: NgForm): void {
    if (form.valid) {
      const index = this.arregloRaton.findIndex(ra => ra.id === this.objetoSeleccionado.id);
      this.actualizarPeriferico(index, this.arregloRaton, this.objetoSeleccionado);
      mostrarMensaje('success', `El Perifercio <b>#${this.objetoSeleccionado.id - 1}<b/>`, 'Actualizado', this.toastr);
      this.resetRaton();
      form.resetForm();
    } else {
      mostrarMensaje("warning", `No se pueden actualizar el <b>${this.titulo}</b> con campos vacíos`, "Advertencia",
        this.toastr);
    }
  }

  public actualizarTeclado(form: NgForm): void {
    if (form.valid) {
      const index = this.arregloTeclado.findIndex(te => te.id === this.objetoSeleccionado.id);
      this.actualizarPeriferico(index, this.arregloTeclado, this.objetoSeleccionado);
      mostrarMensaje('success', `El Perifercio <b>#${this.objetoSeleccionado.id - 1}<b/>`, 'Actualizado', this.toastr);
      this.resetTeclado();
      form.resetForm();
    } else {
      mostrarMensaje("warning", `No se pueden actualizar el <b>${this.titulo}</b> con campos vacíos`, "Advertencia",
        this.toastr);
    }
  }

  public cancelForm(form: NgForm): void {

    if (this.objetoSeleccionado instanceof Raton) {
      this.resetRaton();
    } else {
      this.resetTeclado();
    }
    form.resetForm();

  }

  public resetRaton(): void {
    this.objetoSeleccionado = globals.inicializarRaton();
    this.misRutas.navigateByUrl("/dash/mouse");
  }

  public resetTeclado(): void {
    this.objetoSeleccionado = globals.inicializarTeclado();
    this.misRutas.navigateByUrl("/dash/keyboard");

  }

}
