import { Component, OnInit, TemplateRef } from '@angular/core';
import { Raton } from '../../../modelos/raton.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ARRAY_RATONES } from '../../../mocks/ratones.mock';
import * as globals from '../../../utilidades/globals/inits.func';


@Component({
  selector: 'app-raton',
  templateUrl: './raton.component.html',
  styleUrl: './raton.component.css'
})
export class RatonComponent {
  public arregloRaton: Raton[];
  public ratonSeleccionado: Raton;

   //*******Variables para la ventana flotante del borrar***********//
   public modalRef: BsModalRef;
   public modalTitulo: string;
   public modalCuerpo: string;
   public modalContenido: string;
   public modalContenidoImg: string;
   public tmpBase64: any;

  constructor(public misRutas: Router, public miModal: BsModalService){
    this.arregloRaton = ARRAY_RATONES;
    this.ratonSeleccionado = globals.inicializarRaton();

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  } 

  public seleccionarRaton(ra: Raton): void {
    this.ratonSeleccionado = ra;
    this.misRutas.navigate(['/dash/mouse/detail', ra.id]); 
  }

  public eliminarRaton(del: Raton): void {
    let pos = 0;
    this.arregloRaton.forEach((_dato, indice, arregloFn) => {
      if (arregloFn[indice] === del) {
        pos = indice;
      }
    });
    this.arregloRaton.splice(pos, 1);
  }

  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarRaton(this.ratonSeleccionado);
    this.btnCancelar();
  }

  public btnCancelar(): void {
    this.modalRef.hide();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Raton): void {
    this.ratonSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Ratón?"
    this.modalContenido = obj.toString();
  }
}