import { Component, OnInit, TemplateRef } from '@angular/core';
import { Orden } from '../../modelos/orden.model';
import { Comprador } from '../../modelos/comprador';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ARRAY_ORDENES } from '../../mocks/ordenes.mock';
import { ARRAY_COMPRADORES } from '../../mocks/compradores.mock';
import * as globals from '../../utilidades/globals/inits.func';
import { mostrarMensaje } from '../../utilidades/mensajes/toast.func';

@Component({
  selector: 'app-comprador',
  templateUrl: './comprador.component.html',
  styleUrl: './comprador.component.css'
})
export class CompradorComponent{
  public arregloOrden: Orden[];
  public arregloCompradores: Comprador[];
  public compradorSeleccionado: Comprador;
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public tmpBase64: any;

  constructor(public misRutas: Router, public miModal: BsModalService, public toastr: ToastrService) {
    this.arregloOrden = ARRAY_ORDENES;
    this.compradorSeleccionado = globals.inicializarComprador();
    this.arregloCompradores = ARRAY_COMPRADORES;

    this.modalRef = this.tmpBase64;
    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.tmpBase64 = null;
  }

  public seleccionarOrden(co: Comprador): void {
    this.compradorSeleccionado = co;
    this.misRutas.navigate(['/dash/buyer/order', co.idComprador]);
  }

  public eliminarComprador(del: Comprador): void {
    var index = this.arregloCompradores.indexOf(del);
    this.arregloCompradores.splice(index, 1);
    mostrarMensaje("success", "Eliminado con exito", "Computador " + this.compradorSeleccionado.fullName(), this.toastr)
    this.misRutas.navigate(['/dash/buyer']);
  }

  public cantidadCompras(comprador: Comprador): number {
    let cantidadCompras: number = 0;
    this.arregloOrden.filter((objOrden) => {
      if (objOrden.comprador == comprador) {
        cantidadCompras++;
      }
    })
    return cantidadCompras;
  }


  // Gestión de la ventana flotante
  // ***********************************************************************
  public abrirModal(plantilla: TemplateRef<any>, objPropietario: Comprador): void {
    this.compradorSeleccionado = objPropietario;
    this.modalRef = this.miModal.show(plantilla, { class: 'modal-md' });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Realmente quiere eliminar el comprador?";
    this.modalContenido = objPropietario.fullName();
  }
  public btnCancelar(): void {
    this.miModal.hide();
  }
  public btnEliminar(): void {
    this.eliminarComprador(this.compradorSeleccionado);
    this.btnCancelar();
  }
}

