import { Component, OnInit } from '@angular/core';
import { Comprador } from '../../modelos/comprador';
import { Orden } from '../../modelos/orden.model';
import { Computador } from '../../modelos/computador.model';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { ARRAY_COMPRADORES } from '../../mocks/compradores.mock';
import { ARRAY_ORDENES } from '../../mocks/ordenes.mock';
import * as globals from '../../utilidades/globals/inits.func';

@Component({
  selector: 'app-orden',
  templateUrl: './orden.component.html',
  styleUrl: './orden.component.css'
})
export class OrdenComponent{

  public arregloCompradores: Comprador[];
  public compradorSeleccionado: Comprador;

  public arregloOrden: Orden[];
  public ordenSeleccionada: Orden;

  public pcSeleccionada: Computador;
  public arregloPcComprador: Orden[];

  // Incicialización parametros en el constructor
  constructor(public misRutas: Router, public route: ActivatedRoute, public toastr: ToastrService, public miModal: BsModalService) {
    this.arregloCompradores = ARRAY_COMPRADORES;
    this.compradorSeleccionado = globals.inicializarComprador();
    this.arregloOrden = ARRAY_ORDENES;
    this.ordenSeleccionada = globals.inicializarOrden();
    this.pcSeleccionada = globals.inicializarPc();
    this.arregloPcComprador = [];
    this.cargarCompradoresYCompras();
  }

  public seleccionarPc(pc: Orden): void {
    this.ordenSeleccionada = pc;
  }

  public cargarCompradoresYCompras(): void {
    this.route.paramMap.subscribe((parametro: ParamMap) => {
      const dato = String(parametro.get("codBuyer"));
      const numero = parseFloat(dato);
      this.arregloCompradores.filter((objPropietario) => {
        if (objPropietario.idComprador === numero) {
          this.compradorSeleccionado = objPropietario;

        }
      });
      this.verComprasPc();
    });
  }

  public verComprasPc(): void {
    this.ordenSeleccionada = globals.inicializarOrden();
    this.arregloPcComprador = [];
    this.arregloOrden.filter((objPc) => {
      if (objPc.comprador === this.compradorSeleccionado) {
        this.arregloPcComprador.push(objPc);
      }
    });
  }

}