import { Component, TemplateRef } from '@angular/core';
import { Computador } from '../../../modelos/computador.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ARREGLO_PC } from '../../../mocks/computadores.mock';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import * as globals from '../../../utilidades/globals/inits.func';

@Component({
  selector: 'app-tabla-computador',
  templateUrl: './tabla-computador.component.html',
  styleUrl: './tabla-computador.component.css'
})
export class TablaComputadorComponent{
  public arregloPc: Computador[];
  public pcSeleccionado: Computador;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;

  // Incicialización parametros en el constructor
  constructor(public misRutas: Router, public toastr: ToastrService, public miModal: BsModalService) {
    this.arregloPc = ARREGLO_PC;
    this.pcSeleccionado = globals.inicializarPc();

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }
  public seleccionarPc(pc: Computador): void {
    this.misRutas.navigate(['/dash/computer/detail', pc.idComputador]);
  } 
  
  public eliminarPc(del: Computador): void {
    let pos = this.arregloPc.indexOf(del)
    this.arregloPc.splice(pos, 1);
    mostrarMensaje("success", "Eliminado con exito", "Computador " + this.pcSeleccionado.nombre, this.toastr)
    this.misRutas.navigate(['/dash/computer']);
  }

  //Codigo para hacer la modal de borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarPc(this.pcSeleccionado);
    this.btnCancelar();
  }

  public btnCancelar(): void {
    this.modalRef.hide();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Computador): void {
    this.pcSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar la computadora?"
    this.modalContenido = `${obj.nombre} $${obj.precio}`;
    this.modalContenidoImg = obj.base64Computador;
  }
  //*********Fin Modal de borrar*********
}
