import { Component, OnInit } from '@angular/core';
import { Computador } from '../../../modelos/computador.model';
import { Monitor } from '../../../modelos/monitor.model';
import { Teclado } from '../../../modelos/teclado.model';
import { Raton } from '../../../modelos/raton.model';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ARREGLO_PC } from '../../../mocks/computadores.mock';
import { ARRAY_MONITORES } from '../../../mocks/monitores.mock';
import { ARRAY_TECLADOS } from '../../../mocks/teclados.mock';
import { ARRAY_RATONES } from '../../../mocks/ratones.mock';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import * as globals from '../../../utilidades/globals/inits.func';

@Component({
  selector: 'app-formulario-computador',
  templateUrl: './formulario-computador.component.html',
  styleUrl: './formulario-computador.component.css'
})
export class FormularioComputadorComponent implements OnInit {
  public pcSeleccionado: Computador;
  public arregloPc: Computador[];
  public arregloMonitor: Monitor[];
  public arregloTeclado: Teclado[];
  public arregloRaton: Raton[];
  public tmpBase64: any;

  // Incicialización parametros en el constructor
  constructor(public route: ActivatedRoute, public misRutas: Router, public toastr: ToastrService) {
    this.arregloPc = ARREGLO_PC;
    this.arregloMonitor = ARRAY_MONITORES;
    this.arregloTeclado = ARRAY_TECLADOS;
    this.arregloRaton = ARRAY_RATONES;
    this.pcSeleccionado = globals.inicializarPc();
    
  }

  ngOnInit(): void {
    this.inicializarCombo();
    this.cargarPc();
  }
  
  public cargarPc(): void {
    this.route.paramMap.subscribe((parametro: ParamMap) => {
      const dato = String(parametro.get("codPc"));
      const numero = parseInt(dato);
      this.arregloPc.find((r) => {
        if (r.idComputador === numero) {
          this.pcSeleccionado = { ...r };
        }
      });
    }); 
  }
  
  public inicializarCombo(): void {
    this.pcSeleccionado.monitor = ARRAY_MONITORES[0];
    this.pcSeleccionado.teclado = ARRAY_TECLADOS[0];
    this.pcSeleccionado.raton = ARRAY_RATONES[0];
  }

  public operaciones(form: NgForm, event: any): void {
    const accion = event.submitter.id;

    switch (accion) {
      case "btnCrearPc":
        this.crearPc();
        break;
      case "btnActualizarPc":
        this.actualizarPc(form);
        break;
    }
  }
  
  public crearPc(): void {
    if (this.validarCamposPc()) {
      mostrarMensaje("success", "Agregado con exito", "El Computador " + this.pcSeleccionado.nombre, this.toastr);     
      this.pcSeleccionado.idComputador = this.arregloPc.length + 1;
      this.arregloPc.push(this.pcSeleccionado)
    }else{
      mostrarMensaje("error", "No se pueden crear el computador<br />con campos vacíos", "Advertencia",this.toastr);
    }
    this.resetPc();
    
    this.inicializarCombo();
  }

  public actualizarPc(form: NgForm): void {
    if (this.validarCamposPc()) {
      const index = this.arregloPc.findIndex(pc => pc.idComputador === this.pcSeleccionado.idComputador);
      if (index !== -1) {
        this.arregloPc[index] = this.pcSeleccionado = { ...this.pcSeleccionado };
        mostrarMensaje("success", "Editado con exito", "El Computador " + this.pcSeleccionado.nombre, this.toastr);
      }
      this.resetPc();
      form.resetForm();
    }else{
      mostrarMensaje("warning", "No se puede actualizar el computador<br />con campos vacíos", "Advertencia",this.toastr);

    }
  }
  //Validación de campos
  public validarCamposPc(): boolean {
    var bandera = true;
    if(this.pcSeleccionado.nombre == "" || this.pcSeleccionado.monitor.idMonitor == 0 || this.pcSeleccionado.raton.id == 0 
    || this.pcSeleccionado.teclado.id == 0 || this.pcSeleccionado.publicoFotoComputador == ""){
      bandera =  false;
    }
    return bandera;
  }

  public resetPc(): void {
    this.misRutas.navigateByUrl("/dash/computer");
    this.pcSeleccionado = globals.inicializarPc();
  }

  public cancelForm(form: NgForm): void {
    this.resetPc();
    form.resetForm();
    this.inicializarCombo();
  }
  
   // Manejo input de la imagen
  // ***********************************************************************
  public seleccionarFoto(objeto: any): any {
    let caja = objeto.target.files[0]
    if (!caja || caja.length == 0) {
      return;
    }
    if (caja.type.match(/image\/*/) == null) {
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(caja);
    reader.onload = () => {
      this.tmpBase64 = reader.result;
      this.pcSeleccionado.publicoFotoComputador = caja.name;
      this.pcSeleccionado.base64Computador = this.tmpBase64;
    };
  }


}
