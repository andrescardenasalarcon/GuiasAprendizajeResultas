export interface Persona {
    primerNombre: string;
    segundoNombre: string;
    primerApellido: string;
    segundoApellido: string;
    documento: string;

    toString(): string;
}