import { Persona } from "./persona.interface";

export class Comprador implements Persona {
    public idComprador: number;
    public primerNombre: string;
    public segundoNombre: string;
    public primerApellido: string;
    public segundoApellido: string;
    public documento: string;
    public nombreFoto: string;
    public base64Comprador: string;
    

    constructor(cod: number, primerNombre: string, segundoNombre: string, primerApellido: string, segundoApellido: string,
        documento: string, nombreFoto: string, fotobase64: string) {
        this.idComprador = cod;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.documento = documento;
        this.nombreFoto = nombreFoto;
        this.base64Comprador = fotobase64;

    }

    public fullName(): string {
        return `${this.primerNombre} ${this.segundoNombre} ${this.primerApellido} ${this.segundoApellido}`
    }
}