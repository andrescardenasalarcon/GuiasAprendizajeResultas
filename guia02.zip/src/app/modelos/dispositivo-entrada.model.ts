export class DispositivoEntrada {
    public dispositivoEntrada: string;
    public marca: string;

    constructor(DispositivoEntrada: string, Marca: string) {
        this.dispositivoEntrada = DispositivoEntrada;
        this.marca = Marca;
    }

    public toString(): string {
        return `Marca: ${this.marca}, Dispositivo de Entrada: ${this.dispositivoEntrada}`;
    }

}