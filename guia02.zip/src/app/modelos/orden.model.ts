import { Comprador } from "./comprador";
import { Computador } from "./computador.model";

export class Orden {
    public idOrden: number;
    public computadoras: Computador;
    public comprador: Comprador;
    public cantidad: number;

    constructor(idOrden: number, computadoras: Computador, comprador: Comprador, cantidad?: number) {
        this.idOrden = idOrden;
        this.computadoras = computadoras;
        this.comprador = comprador;         
        if (typeof cantidad !== "undefined") {
            this.cantidad = cantidad;
        } else {
            this.cantidad = 1;
        }

    }

    public getTotal(): string {
        const IVA = 0.19;
        const precioPc: number = this.computadoras.getPrice!();
        return (((precioPc * (IVA + 1)) * this.cantidad)).toFixed(2);
    }
}