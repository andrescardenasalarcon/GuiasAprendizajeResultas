import { DispositivoEntrada } from "./dispositivo-entrada.model";

export class Teclado extends DispositivoEntrada {
    public id: number;

    constructor(id: number, DispositivoEntrada: string, Marca: string) {
        super(DispositivoEntrada, Marca);
        this.id = id;
    }

    public override toString(): string {
        return super.toString()
    }
}