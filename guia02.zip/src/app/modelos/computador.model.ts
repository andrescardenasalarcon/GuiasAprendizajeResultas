import { Monitor } from "./monitor.model";
import { Raton } from "./raton.model";
import { Teclado } from "./teclado.model";

export class Computador {
    public idComputador: number;
    public nombre: string;
    public monitor: Monitor;
    public raton: Raton;
    public teclado: Teclado;
    public publicoFotoComputador: string;
    public base64Computador: string;
    public precio?: number;

    constructor(idComputador: number, nombre: string, monitor: Monitor, raton: Raton, teclado: Teclado, pubFoto: string, base64: string, precio?: number) {
        this.idComputador = idComputador;
        this.nombre = nombre;
        this.monitor = monitor;
        this.raton = raton;
        this.teclado = teclado;
        this.publicoFotoComputador = pubFoto;
        this.base64Computador = base64;
        if (typeof precio !== "undefined") {
            this.precio = precio;
        }
        this.precio = 1000;
    }

    public getPrice?(): number {
        if (typeof this.precio !== "undefined") {
            return this.precio;
        }
        return 1000;
    }

    public toString(): string {
        return `Nombre: ${this.nombre}, Monitor: ${this.monitor.marca}, Raton: ${this.raton.marca}, Teclado: ${this.teclado.marca}`;
    }


}