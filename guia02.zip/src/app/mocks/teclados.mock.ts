import { Teclado } from "../modelos/teclado.model";

export const ARRAY_TECLADOS: Array<Teclado> = [
    new Teclado(1, "", "Seleccione un teclado"),
    new Teclado(2, "Cable", "Asus"),
    new Teclado(3, "Inalambrico", "Razer"),
    new Teclado(4, "Cable", "Lenovo"),
    new Teclado(5, "Cable - Inalambrico", "Acer"),
    new Teclado(6, "Cable - BT", "Samnsung"),
    new Teclado(7, "Bluetooth", "Razer"),
    new Teclado(8, "USB - Inalambrico", "RedDragon"),
];
