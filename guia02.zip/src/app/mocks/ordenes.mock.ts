import { Orden } from "../modelos/orden.model";
import { ARRAY_COMPRADORES } from "./compradores.mock";
import { ARREGLO_PC } from "./computadores.mock";

export const ARRAY_ORDENES: Array<Orden> = [
    new Orden(0, ARREGLO_PC[0], ARRAY_COMPRADORES[0]),
    new Orden(1, ARREGLO_PC[2], ARRAY_COMPRADORES[0], 2),
    new Orden(2, ARREGLO_PC[3], ARRAY_COMPRADORES[1], 1),
    new Orden(3, ARREGLO_PC[1], ARRAY_COMPRADORES[3], 3),
];