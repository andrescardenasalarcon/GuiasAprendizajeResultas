import { Computador } from "../modelos/computador.model";
import { ARRAY_MONITORES } from "./monitores.mock";
import { ARRAY_RATONES } from "./ratones.mock";
import { ARRAY_TECLADOS } from "./teclados.mock";

export const ARREGLO_PC: Array<Computador> = [
    new Computador(1, "Gaming", ARRAY_MONITORES[1], ARRAY_RATONES[2], ARRAY_TECLADOS[2], "", ""),
    new Computador(2, "Oficina", ARRAY_MONITORES[3], ARRAY_RATONES[1], ARRAY_TECLADOS[7], "", ""),
    new Computador(3, "Empresarial", ARRAY_MONITORES[4], ARRAY_RATONES[6], ARRAY_TECLADOS[5], "", ""),
    new Computador(4, "Basico", ARRAY_MONITORES[2], ARRAY_RATONES[5], ARRAY_TECLADOS[4], "", ""),

];


