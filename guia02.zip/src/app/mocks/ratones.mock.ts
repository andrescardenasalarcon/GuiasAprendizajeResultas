import { Raton } from "../modelos/raton.model";

export const ARRAY_RATONES: Array<Raton> = [
    new Raton(1, "", "Seleccione un ratón"),
    new Raton(2, "Cable", "Hp"),
    new Raton(3, "Bluetooth", "Lenovo"),
    new Raton(4, "Cable - Bluetooth", "RedDragon"),
    new Raton(5, "Inalambrico USB", "Hp"),
    new Raton(6, "Bluetooth", "Acer"),
    new Raton(7, "Cable - Bluetooth", "Genrecico"),
    new Raton(8, "Cable", "Acer"),
]
