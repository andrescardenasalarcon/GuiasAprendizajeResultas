import { Comprador } from "../modelos/comprador";

export const ARRAY_COMPRADORES: Array<Comprador> = [
    new Comprador(1, "Andres", "Felipe", "Cardenas", "Alarcon", "10246862", "", ""),
    new Comprador(2, "Juan", "Pablo", "Robles", "Arias", "102487625", "", ""),
    new Comprador(3, "Luis", "Felipe", "Chaparro", "Hurtado", "100245854", "", ""),
    new Comprador(4, "Santiago", "Andrés", "Arias", "Rojo", "40476533", "", ""),
    new Comprador(6, "Brian", "Hernando", "Rodriguez", "Rodriguez", "40476533", "", ""),
    new Comprador(7, "Juan", "Sebastian", "Fonseca", "Fonseca", "40476533", "", ""),

];






