import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CuerpoComponent } from './dashboard/cuerpo/cuerpo.component';
import { InicioComponent } from './dashboard/inicio/inicio.component';
import { TablaComputadorComponent } from './componente/computador/tabla-computador/tabla-computador.component';
import { FormularioComputadorComponent } from './componente/computador/formulario-computador/formulario-computador.component';
import { CompradorComponent } from './componente/comprador/comprador.component';
import { OrdenComponent } from './componente/orden/orden.component';
import { MonitorComponent } from './componente/periferico/monitor/monitor.component';
import { RatonComponent } from './componente/periferico/raton/raton.component';
import { FormularioPerifericoComponent } from './componente/periferico/formulario-periferico/formulario-periferico.component';
import { TecladoComponent } from './componente/periferico/teclado/teclado.component';
import { NoEncontradoComponent } from './componente/no-encontrado/no-encontrado.component';

const routes: Routes = [
  { path: 'root', component: InicioComponent },
  {
    path: 'dash', component: CuerpoComponent,
    children: [
      { path: 'root', component: InicioComponent },
      {
        path: 'computer', component: TablaComputadorComponent,
        children: [
          { path: 'detail/:codPc', component: FormularioComputadorComponent },
          { path: '', component: FormularioComputadorComponent }
        ]
      },
      {
        path: 'buyer', component: CompradorComponent,
        children: [
          { path: 'order/:codBuyer', component: OrdenComponent },
          { path: '', component: OrdenComponent },
        ]
      },
      { path: 'monitor', component: MonitorComponent },
      {
        path: 'mouse', component: RatonComponent,
        children: [
          { path: 'detail/:codP', component: FormularioPerifericoComponent },
          { path: '', component: FormularioPerifericoComponent }
        ]
      },
      {
        path: 'keyboard', component: TecladoComponent,
        children: [
          { path: 'detail/:codP', component: FormularioPerifericoComponent },
          { path: '', component: FormularioPerifericoComponent }
        ]
      },
      { path: '', redirectTo: 'dash', pathMatch: 'full' },
      { path: '**', component: NoEncontradoComponent }
    ],
  },
  { path: '', redirectTo: 'root', pathMatch: 'full' },
  { path: '**', component: NoEncontradoComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
