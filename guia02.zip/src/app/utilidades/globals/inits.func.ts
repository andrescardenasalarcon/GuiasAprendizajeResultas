import { Comprador } from "../../modelos/comprador";
import { Computador } from "../../modelos/computador.model";
import { Monitor } from "../../modelos/monitor.model";
import { Orden } from "../../modelos/orden.model";
import { Raton } from "../../modelos/raton.model";
import { Teclado } from "../../modelos/teclado.model";

export function inicializarMonitor(): Monitor {
    return new Monitor(0, "", 0, "", "");
}

export function inicializarRaton(): Raton {
    return new Raton(0, "", "");
}
export function inicializarTeclado(): Teclado {
    return new Teclado(0, "", "");
}

export function inicializarPc(): Computador {
    return new Computador(0, "", inicializarMonitor(), inicializarRaton(), inicializarTeclado(), "", "");
}

export function inicializarComprador(): Comprador {
    return new Comprador(0, "", "", "", "", "", "", "");
}

export function inicializarOrden(): Orden {
    return new Orden(0, inicializarPc(), inicializarComprador());
}