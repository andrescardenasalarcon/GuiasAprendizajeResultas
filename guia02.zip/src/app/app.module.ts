import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CabeceraComponent } from './dashboard/cabecera/cabecera.component';
import { CuerpoComponent } from './dashboard/cuerpo/cuerpo.component';
import { InicioComponent } from './dashboard/inicio/inicio.component';
import { CompradorComponent } from './componente/comprador/comprador.component';
import { FormularioComputadorComponent } from './componente/computador/formulario-computador/formulario-computador.component';
import { TablaComputadorComponent } from './componente/computador/tabla-computador/tabla-computador.component';
import { OrdenComponent } from './componente/orden/orden.component';
import { FormularioPerifericoComponent } from './componente/periferico/formulario-periferico/formulario-periferico.component';
import { MonitorComponent } from './componente/periferico/monitor/monitor.component';
import { RatonComponent } from './componente/periferico/raton/raton.component';
import { TecladoComponent } from './componente/periferico/teclado/teclado.component';
import { NoEncontradoComponent } from './componente/no-encontrado/no-encontrado.component';


@NgModule({
  declarations: [
    AppComponent,
    CabeceraComponent,
    CuerpoComponent,
    InicioComponent,
    CompradorComponent,
    FormularioComputadorComponent,
    TablaComputadorComponent,
    OrdenComponent,
    FormularioPerifericoComponent,
    MonitorComponent,
    RatonComponent,
    TecladoComponent,
    NoEncontradoComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ModalModule.forRoot(),
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
