import { Component } from '@angular/core';

@Component({
  selector: 'app-cuerpo-priv',
  templateUrl: './cuerpo-priv.component.html',
  styleUrl: './cuerpo-priv.component.css'
})
export class CuerpoPrivComponent {

}
