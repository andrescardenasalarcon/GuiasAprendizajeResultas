import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuerpoPrivComponent } from './cuerpo-priv.component';

describe('CuerpoPrivComponent', () => {
  let component: CuerpoPrivComponent;
  let fixture: ComponentFixture<CuerpoPrivComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CuerpoPrivComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CuerpoPrivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
