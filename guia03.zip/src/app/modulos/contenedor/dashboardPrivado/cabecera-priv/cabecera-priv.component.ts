import { Component } from '@angular/core';
import { MiSesion } from '../../../../modelos/mi-sesion.model';
import { InicioSesionService } from '../../../../servicios/inicio-sesion.service';

@Component({
  selector: 'app-cabecera-priv',
  templateUrl: './cabecera-priv.component.html',
  styleUrls: ['./cabecera-priv.component.css']
})
export class CabeceraPrivComponent {
  public titulo: string;
  public objMiSesion: MiSesion;
  constructor(public sesion: InicioSesionService) {
    this.titulo = 'Rutas padre, hijas y nietas';
    this.objMiSesion = sesion.obtenerDatosSesion();
  }
}