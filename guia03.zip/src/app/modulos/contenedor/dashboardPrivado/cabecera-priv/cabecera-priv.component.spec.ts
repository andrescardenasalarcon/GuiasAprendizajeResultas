import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraPrivComponent } from './cabecera-priv.component';

describe('CabeceraPrivComponent', () => {
  let component: CabeceraPrivComponent;
  let fixture: ComponentFixture<CabeceraPrivComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CabeceraPrivComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CabeceraPrivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
