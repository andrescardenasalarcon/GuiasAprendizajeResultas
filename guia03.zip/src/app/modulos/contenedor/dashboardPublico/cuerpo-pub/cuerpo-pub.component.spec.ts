import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuerpoPubComponent } from './cuerpo-pub.component';

describe('CuerpoPubComponent', () => {
  let component: CuerpoPubComponent;
  let fixture: ComponentFixture<CuerpoPubComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CuerpoPubComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CuerpoPubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
