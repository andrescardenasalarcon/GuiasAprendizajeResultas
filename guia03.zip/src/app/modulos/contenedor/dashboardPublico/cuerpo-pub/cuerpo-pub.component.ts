import { Component } from '@angular/core';

@Component({
  selector: 'app-cuerpo-pub',
  templateUrl: './cuerpo-pub.component.html',
  styleUrl: './cuerpo-pub.component.css'
})
export class CuerpoPubComponent {

}
