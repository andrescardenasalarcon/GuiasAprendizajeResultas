import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecera-pub',
  templateUrl: './cabecera-pub.component.html',
  styleUrl: './cabecera-pub.component.css'
})
export class CabeceraPubComponent {
  
  public titulo: string;
  constructor() {
    this.titulo = 'Rutas padre, hijas y nietas';
  }
}
