import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraPubComponent } from './cabecera-pub.component';

describe('CabeceraPubComponent', () => {
  let component: CabeceraPubComponent;
  let fixture: ComponentFixture<CabeceraPubComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CabeceraPubComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CabeceraPubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
