import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CabeceraPrivComponent } from './dashboardPrivado/cabecera-priv/cabecera-priv.component';
import { CuerpoPrivComponent } from './dashboardPrivado/cuerpo-priv/cuerpo-priv.component';
import { CabeceraPubComponent } from './dashboardPublico/cabecera-pub/cabecera-pub.component';
import { CuerpoPubComponent } from './dashboardPublico/cuerpo-pub/cuerpo-pub.component';

import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    CabeceraPrivComponent,
    CuerpoPrivComponent,
    CabeceraPubComponent,
    CuerpoPubComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [CabeceraPubComponent, CuerpoPubComponent]
})
export class ContenedorModule { }
