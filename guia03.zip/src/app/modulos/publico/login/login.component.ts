import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import * as CryptoJS from "crypto-js";
import { ToastrService } from 'ngx-toastr';
import { Subscription, catchError, map } from 'rxjs';
import { InicioSesion } from '../../../modelos/inicio-sesion.model';
import { InicioSesionService } from '../../../servicios/inicio-sesion.service';
import { RespuestaInicioSesion } from '../../../modelos/respuesta-inicio-sesion.model';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../utilidades/observadores/observadores-any';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  public objUsuario: InicioSesion;
  public subscription: Subscription;
  public patronCorreo = '[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$';

  constructor(private router: Router, public accesoServicio: InicioSesionService, public toastr: ToastrService) {
    this.objUsuario = new InicioSesion("", "");
    this.subscription = Subscription.EMPTY;
  }

  ngOnInit(): void {

  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public operacion(formulario: NgForm): void {
    const miCorreo = this.objUsuario.emailUser;
    const miHash = String(CryptoJS.MD5(this.objUsuario.password));
    const miObj = new InicioSesion(miCorreo, miHash);
    this.subscription = this.accesoServicio.iniciarSesionBackend(miObj).pipe(
      map((resultado: RespuestaInicioSesion) => {
        localStorage.setItem('token_backend', resultado.tokenBackend);
        mostrarMensaje('success', 'Bienvenido al sistema', 'Correcto', this.toastr);
        this.router.navigate(['/private/']);
        formulario.reset();
      }),
      catchError((err) => {
        mostrarMensaje('error', 'Falló el Login', 'Error', this.toastr);
        formulario.reset();
        throw err;
      })
    ).subscribe(ObservadoresAny);

  }
}
