import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PublicoRoutingModule } from './publico-routing.module';
import { ErrorPublicoComponent } from './error-publico/error-publico.component';
import { InicioComponent } from './inicio/inicio.component';
import { LoginComponent } from './login/login.component';
import { SigninComponent } from './signin/signin.component';

import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { ContenedorModule } from '../contenedor/contenedor.module';


@NgModule({
  declarations: [
    ErrorPublicoComponent,
    InicioComponent,
    LoginComponent,
    SigninComponent
  ],
  imports: [
    CommonModule,
    PublicoRoutingModule,
    FormsModule,
    ToastrModule.forRoot(),
    ContenedorModule
  ]
})
export class PublicoModule { }
