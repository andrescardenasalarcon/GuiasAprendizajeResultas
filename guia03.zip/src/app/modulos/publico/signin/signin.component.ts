import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription, catchError, map } from 'rxjs';
import * as CryptoJS from "crypto-js";
import { NgForm } from '@angular/forms';
import { RegistroSesion } from '../../../modelos/registro-sesion.model';
import { RegistroSesionService } from '../../../servicios/registro-sesion.service';
import { RespuestaInicioSesion } from '../../../modelos/respuesta-inicio-sesion.model';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../utilidades/observadores/observadores-any';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit, OnDestroy {

  private tmp: any;
  public objUsuario: RegistroSesion;
  public miSuscripcion: Subscription;
  public patronCorreo = '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';

  constructor(private router: Router, public registroServicio: RegistroSesionService, public toastr: ToastrService) {
    this.objUsuario = new RegistroSesion("", "", "");
    this.miSuscripcion = this.tmp;
  }
  ngOnInit(): void {

  }
  ngOnDestroy(): void {

    if (this.miSuscripcion) {
      this.miSuscripcion.unsubscribe()
    }
  }

  public operacion(formulario: NgForm): void {
    const miNombre = this.objUsuario.nombreUsuario;
    const miApellido = this.objUsuario.apellidoUsuario;
    const fullName = miNombre!.concat(" ", miApellido!);
    const miCorreo = this.objUsuario.emailUser;
    const miHash = String(CryptoJS.MD5(this.objUsuario.password));
    const miObj = new RegistroSesion(fullName, miCorreo, miHash);
    this.miSuscripcion = this.registroServicio.registroSesionBack(miObj).pipe(
      map((resultado: RespuestaInicioSesion) => {
        localStorage.setItem('token_backend', resultado.tokenBackend);
        this.router.navigate(['/private/dash']);
        mostrarMensaje('success', 'Bienvenido al sistema', 'Correcto', this.toastr);
        formulario.reset();
      }), catchError((err) => {
        mostrarMensaje('error', 'Falló el Registro', 'Error', this.toastr);
        formulario.reset();
        throw err;
      })
    ).subscribe(ObservadoresAny);
  }

}
