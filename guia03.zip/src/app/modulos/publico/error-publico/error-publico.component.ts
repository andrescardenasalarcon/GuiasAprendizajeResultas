import { Location } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-error-publico',
  templateUrl: './error-publico.component.html',
  styleUrl: './error-publico.component.css'
})
export class ErrorPublicoComponent {
  constructor(private destino: Location) { }
  public regresar(): void {
    this.destino.back();

  }
}
