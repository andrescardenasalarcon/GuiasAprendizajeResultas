import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorPublicoComponent } from './error-publico.component';

describe('ErrorPublicoComponent', () => {
  let component: ErrorPublicoComponent;
  let fixture: ComponentFixture<ErrorPublicoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ErrorPublicoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ErrorPublicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
