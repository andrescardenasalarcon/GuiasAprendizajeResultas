import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subscription, finalize, map } from 'rxjs';
import { CompradorService } from '../../../servicios/comprador.service';
import { Orden } from '../../../modelos/orden.model';
import { Comprador } from '../../../modelos/comprador.model';
import { OrdenService } from '../../../servicios/orden.service';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../utilidades/observadores/observadores-any';
import * as globals from '../../../utilidades/inits';

@Component({
  selector: 'app-comprador',
  templateUrl: './comprador.component.html',
  styleUrls: ['./comprador.component.css']
})
export class CompradorComponent implements OnInit, OnDestroy {

  public tmp: any;
  public cargaFinalizada: boolean;  
  public subscription: Subscription;
  public arregloOrden: Orden[];
  public arregloCompradores: Comprador[];
  public compradorSeleccionado: Comprador;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public tmpBase64: any;

  constructor(private compradorService: CompradorService, private ordenService: OrdenService, public misRutas: Router,
     public miModal: BsModalService, public toastr: ToastrService) {
    this.cargaFinalizada = false;
    this.arregloOrden = [];
    this.arregloCompradores = [];
    this.subscription = this.tmp;
    this.compradorSeleccionado = globals.inicializarComprador();

    this.modalRef = this.tmpBase64;
    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.tmpBase64 = null;
  }

  ngOnInit(): void {
    this.obtenerCompradoresBackend();
    this.obtenerOrdenesBackend();
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public seleccionarOrden(co: Comprador): void {
    this.compradorSeleccionado = co;
    this.misRutas.navigate(['private/dash/buyer/order', co.idComprador]);
  }

  public eliminarComprador(objBorrar: number): void {
    this.compradorService.borrarComprador(objBorrar).subscribe(() => {
      this.arregloCompradores = this.arregloCompradores.filter(c => c.idComprador !== objBorrar)
      mostrarMensaje("success", "Eliminado con exito", "Computador " + this.compradorSeleccionado.fullName(), this.toastr)
    })
  }

  public cantidadCompras(comprador: number): number {
    let cantidadCompras: number = 0;
    if (this.arregloOrden.length > 0) {
      this.arregloOrden.filter((obj) => {
        if (obj.comprador.idComprador == comprador) {
          cantidadCompras += obj.cantidad;
        }
      })
    }
    return cantidadCompras;
  }

  public obtenerCompradoresBackend(): void {
    this.subscription = this.compradorService
      .obtenerComprador()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.arregloCompradores = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }

  public obtenerOrdenesBackend(): any {
    this.subscription = this.ordenService
      .obtenerOrden()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.arregloOrden = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }
  
  // Gestión de la ventana flotante
  // ***********************************************************************
  public abrirModal(plantilla: TemplateRef<any>, objComprador: Comprador): void {
    this.compradorSeleccionado = objComprador;
    this.modalRef = this.miModal.show(plantilla, { class: 'modal-md' });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Realmente quiere eliminar el comprador?";
    this.modalContenido = `${objComprador.primerNombre} ${objComprador.primerApellido}`;
    
  }
  public btnCancelar(): void {
    this.miModal.hide();
  }
  public btnEliminar(): void {
    this.eliminarComprador(this.compradorSeleccionado.idComprador);
    this.btnCancelar();
    this.misRutas.navigate(['private/dash/buyer']);
  }
}

