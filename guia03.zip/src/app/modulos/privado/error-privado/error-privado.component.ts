import { Component } from '@angular/core';
import { Location } from '@angular/common';
@Component({
  selector: 'app-error-privado',
  templateUrl: './error-privado.component.html',
  styleUrl: './error-privado.component.css'
})
export class ErrorPrivadoComponent {
  constructor(private destino: Location) { }
  public regresar(): void {
    this.destino.back();

  }
}
