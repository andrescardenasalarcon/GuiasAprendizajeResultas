import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorPrivadoComponent } from './error-privado.component';

describe('ErrorPrivadoComponent', () => {
  let component: ErrorPrivadoComponent;
  let fixture: ComponentFixture<ErrorPrivadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ErrorPrivadoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ErrorPrivadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
