import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ComputadorComponent } from './computador/computador/computador.component';
import { FormularioComputadorComponent } from './computador/formulario-computador/formulario-computador.component';
import { CompradorComponent } from './comprador/comprador.component';
import { OrdenComponent } from './orden/orden.component';
import { VenderComponent } from './vender/vender.component';
import { MonitorComponent } from './perifericos/monitor/monitor.component';
import { RatonComponent } from './perifericos/raton/raton.component';
import { FormularioPerifericoComponent } from './perifericos/formulario-periferico/formulario-periferico.component';
import { TecladoComponent } from './perifericos/teclado/teclado.component';
import { ErrorPrivadoComponent } from './error-privado/error-privado.component';

const routes: Routes = [
  {
    path: 'computer', component: ComputadorComponent,
    children: [
      { path: 'detail/:codPc', component: FormularioComputadorComponent },
      { path: '', component: FormularioComputadorComponent }
    ]
  },
  {
    path: 'buyer', component: CompradorComponent,
    children: [
      { path: 'order/:codBuyer', component: OrdenComponent },
      { path: '', component: OrdenComponent },
    ]
  },
  { path: 'cash', component: VenderComponent },

  { path: 'monitor', component: MonitorComponent },
  {
    path: 'mouse', component: RatonComponent,
    children: [
      { path: 'detail/:codP', component: FormularioPerifericoComponent },
      { path: '', component: FormularioPerifericoComponent }
    ]
  },

  {
    path: 'keyboard', component: TecladoComponent,
    children: [
      { path: 'detail/:codP', component: FormularioPerifericoComponent },
      { path: '', component: FormularioPerifericoComponent }
    ]
  },

  { path: '', redirectTo: 'computer', pathMatch: 'full' },
  { path: '**', component: ErrorPrivadoComponent }, //Ruta que no existe

];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class PrivadoRoutingModule { }
