import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subscription, finalize, map } from 'rxjs';

import * as globals from '../../../utilidades/inits';
import { Comprador } from '../../../modelos/comprador.model';
import { Orden } from '../../../modelos/orden.model';
import { Computador } from '../../../modelos/computador.model';
import { CompradorService } from '../../../servicios/comprador.service';
import { OrdenService } from '../../../servicios/orden.service';
import { ObservadoresAny } from '../../../utilidades/observadores/observadores-any';
@Component({
  selector: 'app-orden',
  templateUrl: './orden.component.html',
  styleUrls: ['./orden.component.css']
})
export class OrdenComponent implements OnInit, OnDestroy {
  public _id: string;
  public tmp: any;
  public cargaFinalizada: boolean;
  public subscription: Subscription;

  public arregloCompradores: Comprador[];
  public compradorSeleccionado: Comprador;

  public arregloOrden: Orden[];
  public ordenSeleccionada: Orden;

  public pcSeleccionada: Computador;
  public arregloPcComprador: Orden[];

  // Incicialización parametros en el constructor
  constructor(private compradorService: CompradorService, private ordenService: OrdenService, public misRutas: Router, public route: ActivatedRoute, public toastr: ToastrService, public miModal: BsModalService) {
    this._id = String(this.route.snapshot.paramMap.get('codBuyer'));
    this.cargaFinalizada = false;
    this.subscription = this.tmp;
    this.arregloCompradores = [];
    this.arregloOrden = [];
    this.ordenSeleccionada = globals.inicializarOrden();
    this.pcSeleccionada = globals.inicializarPc();
    this.arregloPcComprador = [];
    this.compradorSeleccionado = globals.inicializarComprador();
  }
  ngOnInit(): void {
    this.route.paramMap.subscribe(async (params: ParamMap) => {
      this._id = String(params.get("codBuyer"));
      if (this._id !== 'null') {
        await this.cargarCompradoresBackend(this._id);
        await this.cargarOrdenesBackend();

      }
    })


  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public seleccionarPc(pc: Orden): void {
    this.ordenSeleccionada = pc;
  }

  public cargarOrdenesDeCompra(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this._id = String(params.get("codBuyer"));
      if (this._id !== 'null') {
        this.cargarCompradoresBackend(this._id);
      }
    })

  }

  public async cargarCompradoresBackend(codOrden: string): Promise<void> {
    this.subscription = this.compradorService.buscarUnComprador(codOrden)
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.compradorSeleccionado = respuesta;

        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);

  }

  public async cargarOrdenesBackend(): Promise<any> {
    this.arregloOrden = [];
    this.subscription = this.ordenService.obtenerOrden()
      .pipe(
        map(async (respuesta: Orden[]) => {
          console.log(respuesta);
          await Promise.all(
            respuesta.map((res) => {
              // const monitorJSON: Monitor = JSON.parse(res.computadoras.monitor.toString());
              // const ratonJSON: Raton = JSON.parse(res.computadoras.raton.toString());
              // const tecladoJSON: Teclado = JSON.parse(res.computadoras.teclado.toString());
              // const compuJSON: Computador = JSON.parse(res.computadoras.toString());

              res.computadoras = Computador.fromJson(res.computadoras);
              res.comprador = Comprador.fromJson(res.comprador);
              // const ord = new Orden(res.idOrden, res.computadoras, res.comprador, res.cantidad);
              // res = ord;

              console.log(res.comprador);
              res = Orden.fromJson(res);
              console.log(res);

              // res.computadoras.monitor = Monitor.fromJson(monitorJSON);
              // res.computadoras.raton = Raton.fromJson(ratonJSON);
              // res.computadoras.teclado = Teclado.fromJson(tecladoJSON);

              this.arregloOrden.push(res);

            })
          )
          console.log(this.arregloOrden);

          await this.verComprasPc();
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);

  }

  public async verComprasPc(): Promise<void> {
    this.ordenSeleccionada = globals.inicializarOrden();
    this.arregloPcComprador = [];
    this.arregloOrden.filter((objPc) => {

      if (Number(objPc.comprador.idComprador) === this.compradorSeleccionado.idComprador) {
        console.log(objPc);
        this.arregloPcComprador.push(objPc);
      }
    });
  }

}