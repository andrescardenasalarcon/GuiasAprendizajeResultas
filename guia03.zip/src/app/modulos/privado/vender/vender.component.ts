
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subscription, catchError, finalize, map } from 'rxjs';

import * as globals from '../../../utilidades/inits';
import { Orden } from '../../../modelos/orden.model';
import { Computador } from '../../../modelos/computador.model';
import { Comprador } from '../../../modelos/comprador.model';
import { OrdenService } from '../../../servicios/orden.service';

import { CompradorService } from '../../../servicios/comprador.service';
import { Router } from '@angular/router';
import { mostrarMensaje } from '../../../utilidades/mensajes/toast.func';
import { NgForm } from '@angular/forms';
import { ObservadoresAny } from '../../../utilidades/observadores/observadores-any';
import { ComputadorService } from '../../../servicios/computador.service';

@Component({
  selector: 'app-vender',
  templateUrl: './vender.component.html',
  styleUrls: ['./vender.component.css']
})
export class VenderComponent implements OnInit, OnDestroy {

  public cargaFinalizada: boolean;
  public subscription: Subscription;
  public orderSeleccionada: Orden;
  public arregloComputadora: Computador[];
  public arregloComprador: Comprador[];

  constructor(private ordenService: OrdenService, private computadorService: ComputadorService, private compradorService: CompradorService, public misRutas: Router, public toastr: ToastrService) {
    this.cargaFinalizada = false;
    this.subscription = Subscription.EMPTY;
    this.orderSeleccionada = globals.inicializarOrden();
    this.arregloComputadora = [];
    this.arregloComprador = [];
  }

  ngOnInit(): void {
    this.obtenerPcBackend();
    this.obtenerCompradoresBackend();

  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public realizarOrden(form: NgForm): void {
    if (this.validarCampos()) {
      this.subscription = this.ordenService.crearOrden(this.orderSeleccionada)
        .pipe(
          map((respuesta) => {
            console.log(this.orderSeleccionada);
            
            mostrarMensaje("success", "Venta realizada con exito", "Al comprador: " + this.orderSeleccionada.comprador.fullName(), this.toastr);
            this.resetOrden();
          }),
          catchError((err) => {
            mostrarMensaje("error", "Falló la venta", "Advertencia", this.toastr);
            throw err;
          })
        ).subscribe(ObservadoresAny);
    } else {
      mostrarMensaje("error", "No se pueden hacer la venta <br />con campos vacíos", "Advertencia", this.toastr);
    }
  }

  public obtenerPcBackend(): void {
    this.subscription = this.computadorService
      .obtenerComputador()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.arregloComputadora = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }
  public obtenerCompradoresBackend(): void {
    this.subscription = this.compradorService
      .obtenerComprador()
      .pipe(
        map((respuesta: Comprador[]) => {
          console.log(respuesta);
          respuesta.map((res) => {
            res = Comprador.fromJson(res)
            this.arregloComprador.push(res);
          })

        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);

  }

  public validarCampos(): boolean {
    if (this.orderSeleccionada.cantidad === 0 || this.orderSeleccionada.comprador === null || this.orderSeleccionada.computadoras === null) {
      return false
    }
    return true;
  }

  public resetOrden(): void {
    this.misRutas.navigateByUrl("private/dash/buyer");
    this.orderSeleccionada = globals.inicializarOrden();
  }


}
