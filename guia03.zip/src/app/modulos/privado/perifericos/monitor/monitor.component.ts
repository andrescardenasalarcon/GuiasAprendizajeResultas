import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription, finalize, map } from 'rxjs';
import * as globals from '../../../../utilidades/inits';
import { Monitor } from '../../../../modelos/monitor.model';
import { MonitorService } from '../../../../servicios/monitor.service';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-monitor',
  templateUrl: './monitor.component.html',
  styleUrl: './monitor.component.css'
})
export class MonitorComponent implements OnInit, OnDestroy {

  public cargaFinalizada: boolean;
  public subscription: Subscription;
  public arregloMonitor: Monitor[];
  public monitorSeleccionado: Monitor;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;

  constructor(private monitorService: MonitorService, public misRutas: Router, public miModal: BsModalService, public toastr: ToastrService) {
    this.cargaFinalizada = false;
    this.arregloMonitor = [];
    this.monitorSeleccionado = globals.inicializarMonitor();
    this.subscription = Subscription.EMPTY;

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }

  ngOnInit(): void {
    this.obtenerMonitoresBackend()
  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public seleccionarMonitor(mo: Monitor): void {
    this.monitorSeleccionado = mo;
  }

  public eliminarMonitor(del: Monitor): void {
    this.monitorService.borrarMonitor(del.idMonitor).subscribe({
      next: () => {
        this.arregloMonitor = this.arregloMonitor.filter((objMonitor) => objMonitor !== del);
        mostrarMensaje("success", "Eliminado con exito", "Monitor " + del, this.toastr);

      },
      error: (error) => {
        // Error: manejar el error y mostrar una modal en función de la respuesta
        if (error.status === 400) {
          // Muestra una modal o mensaje específico para el error de eliminación
          mostrarMensaje("warning", "A un Computador", "Monitor ya asociado", this.toastr);
        } else {
          // Maneja otros posibles errores
          mostrarMensaje("warning", "A un Computador", "Monitor ya asociado", this.toastr);
        }
      }
    })

  }

  public obtenerMonitoresBackend(): void {
    this.subscription = this.monitorService
      .obtenerMonitor()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.arregloMonitor = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  };

  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarMonitor(this.monitorSeleccionado);
    this.btnCancelar();
  }

  public btnCancelar(): void {
    this.modalRef.hide();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Monitor): void {
    this.monitorSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Monitor?"
    this.modalContenido = `${obj.marca} ${obj.tamanno}`;
    this.modalContenidoImg = obj.base64Monitor;
  }
}

