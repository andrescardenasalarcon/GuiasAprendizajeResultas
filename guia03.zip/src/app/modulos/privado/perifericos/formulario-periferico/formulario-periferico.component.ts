import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription, catchError, finalize, map } from 'rxjs';

import * as globals from '../../../../utilidades/inits';
import { Raton } from '../../../../modelos/raton.model';
import { Teclado } from '../../../../modelos/teclado.model';
import { TecladoService } from '../../../../servicios/teclado.service';
import { RatonService } from '../../../../servicios/raton.service';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';

@Component({
  selector: 'app-formulario-periferico',
  templateUrl: './formulario-periferico.component.html',
  styleUrl: './formulario-periferico.component.css'
})
export class FormularioPerifericoComponent implements OnInit, OnDestroy {
  public titulo: string = '';
  public _id: string | any;
  public cargaFinalizada: boolean;
  public flag: boolean;
  public subscription: Subscription;
  public tmp: any;
  public objetoSeleccionado: Raton | Teclado;

  constructor(private route: ActivatedRoute, private misRutas: Router, public toastr: ToastrService, 
    private ratonService: RatonService, private tecladoService: TecladoService) {
    this.cargaFinalizada = false;
    this.flag = true;
    this.subscription = this.tmp;
    this.objetoSeleccionado = globals.inicializarRaton();
  }

  ngOnInit(): void {
    this._id = String(this.route.snapshot.paramMap.get("codP"));
    this.urlTitle();

  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }


  public async urlTitle(): Promise<void> {
    const url = this.misRutas.url;
    this.titulo = url.includes('mouse') ? 'Ratón' : 'Teclado';
    if (url.includes('mouse')) {
      this.objetoSeleccionado = globals.inicializarRaton();
      this.flag = true;
    } else {
      this.objetoSeleccionado = globals.inicializarTeclado();
      this.flag = false;
    }

    if (this._id !== 'null') {
      await this.cargarPeriferico(this._id);
    }
  };

  public async cargarPeriferico(codPeriferico: string): Promise<void> {

    if (this.objetoSeleccionado instanceof Raton) {
      this.subscription = this.ratonService.buscarUnRaton(codPeriferico)
        .pipe(
          map((respuesta: Raton) => {
            console.log(respuesta);
            this.objetoSeleccionado = respuesta as Raton;

          }),
          finalize(() => {
            this.cargaFinalizada = true;
          })
        ).subscribe(ObservadoresAny);
    } else {
      this.subscription = this.tecladoService.buscarUnTeclado(codPeriferico)
        .pipe(
          map((respuesta: Teclado) => {
            console.log(respuesta);
            this.objetoSeleccionado = respuesta as Teclado;

          }),
          finalize(() => {
            this.cargaFinalizada = true;
          })
        ).subscribe(ObservadoresAny);
    }

  }


  public operacionesPerifericos(form: NgForm, event: any): void {
    const accion = event.submitter.id

    switch (accion) {
      case "crearPeriferico":
        this.crearPeriferico(form);
        break;
      case "actualizarPeriferico":
        this.actualizacionPerifericos(form);
        break;
    }
  }


  public crearPeriferico(form: NgForm): void {
    if (form.valid) {
      if (this.objetoSeleccionado instanceof Raton) {
        this.crearRaton();
        this.resetRaton();
      } else {
        this.crearTeclado();
        this.resetTeclado();
      }
      form.resetForm();
    } else {
      mostrarMensaje("error", "No se pueden crear Perifericos<br />con campos vacíos", "Advertencia", this.toastr);

    }
  }
  public actualizacionPerifericos(form: NgForm): void {
    if (form.valid) {
      if (this.flag) {
        this.actualizarRaton(form);
      } else {
        this.actualizarTeclado(form);
      }
      form.resetForm();
    } else {
      mostrarMensaje("error", "No se puede actualizar el Periferico<br />con campos vacíos", "Advertencia", this.toastr);
    }


  }
  public crearRaton(): void {
    const miId = this.objetoSeleccionado.id;
    const miDispositivoEntrada = this.objetoSeleccionado.dispositivoEntrada;
    const miMarca = this.objetoSeleccionado.marca;
    const newRat = new Raton(miId, miDispositivoEntrada, miMarca);
    this.subscription = this.ratonService.crearRaton(newRat).pipe(
      map((res) => {
        mostrarMensaje('success', `Nuevo Periferico de tipo Ratón Creado!`, 'Añadido', this.toastr);
        this.ratonService.notificarActualizacionLista();
      }),
      catchError((err) => {
        mostrarMensaje('error', 'Falló la creación del periferico', 'Error', this.toastr);
        throw err;
      })
    ).subscribe(ObservadoresAny);
  }

  public crearTeclado(): void {
    const ids = this.objetoSeleccionado.id;
    const miDis = this.objetoSeleccionado.dispositivoEntrada;
    const mar = this.objetoSeleccionado.marca;
    const newRat = new Teclado(ids, miDis, mar);
    this.subscription = this.tecladoService.crearTeclado(newRat).pipe(
      map((res) => {
        mostrarMensaje('success', `Nuevo Periferico de tipo Teclado Creado!`, 'Añadido', this.toastr);
        this.tecladoService.notificarActualizacionLista();
      }),
      catchError((err) => {
        mostrarMensaje('error', 'Falló la creación del periferico', 'Error', this.toastr);
        throw err;

      })
    ).subscribe(ObservadoresAny);
    this.resetTeclado();
  }


  public actualizarRaton(form: NgForm): void {

    if (form.valid) {
      this.subscription = this.ratonService.actualizarRaton(this.objetoSeleccionado).pipe(
        map((respuesta) => {
          mostrarMensaje('success', `El Perifercio <b>#${this.objetoSeleccionado.id}<b/>`, 'Actualizado', this.toastr);
          this.ratonService.notificarActualizacionLista();
          this.resetRaton();
        }),
        catchError((err) => {
          mostrarMensaje('error', 'Falló la actualización del periferico', 'Error', this.toastr);
          form.reset();
          throw err;
        })
      ).subscribe(ObservadoresAny);
    } else {
      mostrarMensaje("warning", `No se pueden actualizar el <b>${this.titulo}</b> con campos vacíos`, "Advertencia", this.toastr);
    }
  }

  public actualizarTeclado(form: NgForm): void {
    if (form.valid) {
      this.subscription = this.tecladoService.actualizarTeclado(this.objetoSeleccionado).pipe(
        map((respuesta: any) => {
          mostrarMensaje('success', `El Perifercio <b>#${this.objetoSeleccionado.id}<b/>`, 'Actualizado', this.toastr);
          this.tecladoService.notificarActualizacionLista();
          this.resetTeclado();
        }),
        catchError((err) => {
          mostrarMensaje('error', 'Falló la actualización del periferico', 'Error', this.toastr);
          form.reset();
          throw err;
        })
      ).subscribe(ObservadoresAny);

    } else {
      mostrarMensaje("warning", `No se pueden actualizar el <b>${this.titulo}</b> con campos vacíos`, "Advertencia", this.toastr);
    }

  }

  public cancelForm(form: NgForm): void {

    if (this.flag) {
      this.resetRaton();
    } else {
      this.resetTeclado();
    }
    form.resetForm();


  }

  public resetRaton(): void {
    this.objetoSeleccionado = globals.inicializarRaton();
    this.misRutas.navigateByUrl("private/dash/mouse");
  }

  public resetTeclado(): void {
    this.objetoSeleccionado = globals.inicializarTeclado();
    this.misRutas.navigateByUrl("private/dash/keyboard");
  }

}
