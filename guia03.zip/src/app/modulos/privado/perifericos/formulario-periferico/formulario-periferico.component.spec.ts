import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioPerifericoComponent } from './formulario-periferico.component';

describe('FormularioPerifericoComponent', () => {
  let component: FormularioPerifericoComponent;
  let fixture: ComponentFixture<FormularioPerifericoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FormularioPerifericoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FormularioPerifericoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
