import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subscription, finalize, map } from 'rxjs';

import * as globals from '../../../../utilidades/inits';
import { Teclado } from '../../../../modelos/teclado.model';
import { TecladoService } from '../../../../servicios/teclado.service';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';

@Component({
  selector: 'app-teclado',
  templateUrl: './teclado.component.html',
  styleUrl: './teclado.component.css'
})
export class TecladoComponent implements OnInit, OnDestroy {
  public tmp: any;
  public cargaFinalizada: boolean;
  public subscription: Subscription;
  public arregloTeclado: Teclado[];
  public tecladoSeleccionado: Teclado;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;


  constructor(private tecladoservice: TecladoService, public misRutas: Router, public toastr: ToastrService, public miModal: BsModalService) {
    this.cargaFinalizada = false;
    this.arregloTeclado = [];
    this.tecladoSeleccionado = globals.inicializarTeclado();
    this.subscription = this.tmp;

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;


  }

  ngOnInit(): void {
    this.obtenerTecladoBackend();
    this.tecladoservice.actualizarListaObservable().subscribe(() => {
      this.obtenerTecladoBackend();
    })
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public seleccionarTeclado(te: Teclado): void {
    this.tecladoSeleccionado = te
    this.misRutas.navigate(['private/dash/keyboard/detail', te.id]);

  }

  public eliminarTeclado(objBorrar: number): void {
    this.tecladoservice.borrarTeclado(objBorrar)
      .subscribe(
        {
          next: () => {
            // Éxito: se eliminó el teclado
            this.arregloTeclado = this.arregloTeclado.filter((t) => t.id !== objBorrar);
            mostrarMensaje("success", "Eliminado con éxito", "Teclado " + objBorrar, this.toastr);
          },
          error: (error) => {
            // Error: manejar el error y mostrar una modal en función de la respuesta
            if (error.status === 400) {
              // Muestra una modal o mensaje específico para el error de eliminación
              mostrarMensaje("warning", "A un Computador", "Teclado ya asociado", this.toastr);
            } else {
              // Maneja otros posibles errores
              mostrarMensaje("warning", "A un Computador", "Teclado ya asociado", this.toastr);
            }
          }
        }
      );
  }


  public obtenerTecladoBackend(): void {
    this.subscription = this.tecladoservice
      .obtenerTeclado()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.arregloTeclado = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);

  }

  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarTeclado(this.tecladoSeleccionado.id);
    this.btnCancelar();
    this.misRutas.navigate(['private/dash/keyboard']);
  }

  public btnCancelar(): void {
    this.modalRef.hide();
    this.tecladoSeleccionado = globals.inicializarTeclado();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Teclado): void {
    this.tecladoSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Teclado?"
    this.modalContenido = `Marca: ${obj.marca}, Dispositivo de Entrada: ${obj.dispositivoEntrada}`;
  }
}