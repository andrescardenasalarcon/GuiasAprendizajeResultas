import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subscription, finalize, map } from 'rxjs';

import * as globals from '../../../../utilidades/inits';
import { Raton } from '../../../../modelos/raton.model';
import { RatonService } from '../../../../servicios/raton.service';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';

@Component({
  selector: 'app-raton',
  templateUrl: './raton.component.html',
  styleUrl: './raton.component.css'
})
export class RatonComponent implements OnInit, OnDestroy {

  public tmp: any;
  public cargaFinalizada: boolean;
  public arregloRaton: Raton[];
  public subscription: Subscription;
  public ratonSeleccionado: Raton;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;

  constructor(private ratonService: RatonService, public misRutas: Router, public toastr: ToastrService, public miModal: BsModalService) {
    this.cargaFinalizada = false;
    this.arregloRaton = [];
    this.ratonSeleccionado = globals.inicializarRaton();
    this.subscription = Subscription.EMPTY;


    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }

  ngOnInit(): void {
    this.obtenerRatonBackend();
    this.ratonService.actualizarListaObservable().subscribe(() => {
      this.obtenerRatonBackend();
    })
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public seleccionarRaton(ra: Raton): void {
    this.ratonSeleccionado = ra;
    this.misRutas.navigate(['private/dash/mouse/detail', ra.id]);
  }

  public eliminarRaton(objBorrar: number): void {
    this.ratonService.borrarRaton(objBorrar).subscribe(
      {
        next: () => {
          this.arregloRaton = this.arregloRaton.filter(
            (r) => r.id !== objBorrar
          )
          mostrarMensaje("success", "Eliminado con exito", "Raton " + objBorrar, this.toastr);
        },

        error: (error) => {
          // Error: manejar el error y mostrar una modal en función de la respuesta
          if (error.status === 400) {
            // Muestra una modal o mensaje específico para el error de eliminación
            mostrarMensaje("warning", "A un Computador", "Raton ya asociado", this.toastr);
          } else {
            // Maneja otros posibles errores
            mostrarMensaje("warning", "A un Computador", "Raton ya asociado", this.toastr);
          }
        }
      }
    )
  }

  public obtenerRatonBackend(): void {
    this.subscription = this.ratonService
      .obtenerRaton()
      .pipe(
        map((respuesta) => {
          this.arregloRaton = respuesta;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }


  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarRaton(this.ratonSeleccionado.id);
    this.btnCancelar();
    this.misRutas.navigate(['private/dash/mouse']);
  }

  public btnCancelar(): void {
    this.modalRef.hide();
    this.ratonSeleccionado = globals.inicializarRaton();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Raton): void {
    this.ratonSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar el Ratón?"
    this.modalContenido = `Marca: ${obj.marca}, Dispositivo de Entrada: ${obj.dispositivoEntrada}`;


  }
}