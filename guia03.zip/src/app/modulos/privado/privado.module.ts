import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompradorComponent } from './comprador/comprador.component';
import { FormularioComputadorComponent } from './computador/formulario-computador/formulario-computador.component';
import { ComputadorComponent } from './computador/computador/computador.component';
import { OrdenComponent } from './orden/orden.component';
import { FormularioPerifericoComponent } from './perifericos/formulario-periferico/formulario-periferico.component';
import { MonitorComponent } from './perifericos/monitor/monitor.component';
import { RatonComponent } from './perifericos/raton/raton.component';
import { TecladoComponent } from './perifericos/teclado/teclado.component';
import { VenderComponent } from './vender/vender.component';
import { ErrorPrivadoComponent } from './error-privado/error-privado.component';

import { PrivadoRoutingModule } from './privado-routing.module';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { ContenedorModule } from '../contenedor/contenedor.module';



@NgModule({
  declarations: [
    CompradorComponent,
    FormularioComputadorComponent,
    ComputadorComponent,
    OrdenComponent,
    FormularioPerifericoComponent,
    MonitorComponent,
    RatonComponent,
    TecladoComponent,
    VenderComponent,
    ErrorPrivadoComponent
  ],
  imports: [
    CommonModule,
    PrivadoRoutingModule,
    FormsModule,
    ToastrModule.forRoot(),
    ContenedorModule
  ]
})
export class PrivadoModule { }
