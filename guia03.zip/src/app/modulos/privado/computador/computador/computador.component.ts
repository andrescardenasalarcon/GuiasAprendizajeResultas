import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subscription, finalize, map } from 'rxjs';

import { Computador } from '../../../../modelos/computador.model';
import { ComputadorService } from '../../../../servicios/computador.service';
import { Monitor } from '../../../../modelos/monitor.model';
import { Teclado } from '../../../../modelos/teclado.model';
import { Raton } from '../../../../modelos/raton.model';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';
import * as globals from '../../../../utilidades/inits';

@Component({
  selector: 'app-computador',
  templateUrl: './computador.component.html',
  styleUrl: './computador.component.css'
})
export class ComputadorComponent implements OnInit, OnDestroy {

  public tmp: any;
  public cargaFinalizada: boolean;
  public subscription: Subscription;
  public arregloPc: Computador[];
  public pcSeleccionado: Computador;

  //*******Variables para la ventana flotante del borrar***********//
  public modalRef: BsModalRef;
  public modalTitulo: string;
  public modalCuerpo: string;
  public modalContenido: string;
  public modalContenidoImg: string;
  public tmpBase64: any;

  // Incicialización parametros en el constructor
  constructor(private computadorService: ComputadorService, public misRutas: Router, public toastr: ToastrService, public miModal: BsModalService) {

    this.cargaFinalizada = false;
    this.arregloPc = [];
    this.pcSeleccionado = globals.inicializarPc();
    this.subscription = this.tmp;

    this.modalTitulo = "";
    this.modalCuerpo = "";
    this.modalContenido = "";
    this.modalContenidoImg = "";
    this.modalRef = this.tmpBase64;
  }

  ngOnInit(): void {
    this.obtenerPcBackend();
    this.computadorService.actualizarListaObservable().subscribe(() => {
      this.obtenerPcBackend();
    })
  }
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  
  public seleccionarPc(pc: Computador): void {
    this.misRutas.navigate(['/private/dash/computer/detail', pc.idComputadora]);
  }

  public eliminarPc(objBorrar: number): void {
    this.subscription = this.computadorService
      .borrarComputador(objBorrar).subscribe(() => {
        this.arregloPc = this.arregloPc.filter(c => c.idComputadora !== objBorrar);
      })
    this.computadorService.notificarActualizacionLista();
    mostrarMensaje("success", "Eliminado con exito", "Computador " + objBorrar, this.toastr)

  }

  public obtenerPcBackend(): void {
    this.arregloPc = [];
    this.subscription = this.computadorService
      .obtenerComputador()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          respuesta.map(miPc => {
            
            miPc.monitor = Monitor.fromJson(miPc.monitor);
            miPc.teclado = Teclado.fromJson(miPc.teclado);
            miPc.raton = Raton.fromJson(miPc.raton);
            
            this.arregloPc.push(miPc);

          });

        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }
  //Codigo para hacer lo de las modales del borrar
  //***************************************** */
  public btnEliminar(): void {
    this.eliminarPc(this.pcSeleccionado.idComputadora);
    this.btnCancelar();
    this.misRutas.navigate(['private/dash/computer']);
  }

  public btnCancelar(): void {
    this.modalRef.hide();
    this.pcSeleccionado = globals.inicializarPc();
  }
  public abrirModal(plantilla: TemplateRef<any>, obj: Computador): void {
    this.pcSeleccionado = obj;
    this.modalRef = this.miModal.show(plantilla, { class: "modal-md" });
    this.modalTitulo = "Advertencia";
    this.modalCuerpo = "¿Desea borrar la computador?"
    this.modalContenido = `Nombre: ${obj.nombre}, Precio: $${obj.precio}`;
    this.modalContenidoImg = obj.base64Computadora;
  }
}
