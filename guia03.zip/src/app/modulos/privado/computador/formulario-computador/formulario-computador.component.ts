
import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription, catchError, finalize, map } from 'rxjs';
import { Computador } from '../../../../modelos/computador.model';
import { Monitor } from '../../../../modelos/monitor.model';
import { Teclado } from '../../../../modelos/teclado.model';
import { Raton } from '../../../../modelos/raton.model';
import { TecladoService } from '../../../../servicios/teclado.service';

import { MonitorService } from '../../../../servicios/monitor.service';
import { RatonService } from '../../../../servicios/raton.service';
import { ComputadorService } from '../../../../servicios/computador.service';
import { mostrarMensaje } from '../../../../utilidades/mensajes/toast.func';
import { ObservadoresAny } from '../../../../utilidades/observadores/observadores-any';
import * as globals from '../../../../utilidades/inits';

@Component({
  selector: 'app-formulario-computador',
  templateUrl: './formulario-computador.component.html',
  styleUrls: ['./formulario-computador.component.css']
})
export class FormularioComputadorComponent implements OnInit, OnDestroy {
  public _id: string | any;
  public cargaFinalizada: boolean;
  public subscription: Subscription;
  public tmp: any;
  public pcSeleccionado: Computador;
  public arregloPc: Computador[];
  public arregloMonitor: Monitor[];
  public arregloTeclado: Teclado[];
  public arregloRaton: Raton[];
  public tmpBase64: any;


  // Incicialización parametros en el constructor
  constructor(public route: ActivatedRoute, public misRutas: Router, public toastr: ToastrService, private computadoraService: ComputadorService, private monitorService: MonitorService, private ratonService: RatonService, private tecladoService: TecladoService) {
    this.cargaFinalizada = false;
    this.subscription = this.tmp;
    this.arregloPc = [];
    this.arregloMonitor = this.obtenerMonitoresBackend();
    this.arregloTeclado = this.obtenerTecladosBackend();
    this.arregloRaton = this.obtenerRatonesBackend();
    this.pcSeleccionado = globals.inicializarPc();
  }

  ngOnInit(): void {
    this.inicializarCombo();
    this.route.paramMap.subscribe(async (params: ParamMap) => {
      this._id = String(params.get("codPc"));
      if (this._id !== 'null') {
        await this.cargarPc(this._id);
      }
    })
    // if (this._id != 'null') {
    //   this.cargarPc(this._id);
    // }else if(tmpId !== this._id){
    //   this.resetPc();
    //   this.cargarPc(this._id);
    // }

  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  public async cargarPc(codPc: string): Promise<void> {

    this.subscription = this.computadoraService.buscarUnComputador(codPc)
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          this.pcSeleccionado = respuesta;
          this.pcSeleccionado.raton = this.arregloRaton.find(r => r.id === Number(respuesta.raton.id))!;
          this.pcSeleccionado.monitor = this.arregloMonitor.find(m => m.idMonitor === Number(respuesta.monitor.idMonitor))!;
          this.pcSeleccionado.teclado = this.arregloTeclado.find(t => t.id === Number(respuesta.teclado.id))!;
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }

  public async inicializarCombo(): Promise<void> {
    // REVISAR COMBO
  }

  public obtenerMonitoresBackend(): any {
    this.subscription = this.monitorService
      .obtenerMonitor()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          respuesta.unshift(new Monitor(0, "Seleccione un monitor ", 0, "", ""));
          this.arregloMonitor = respuesta;
          this.pcSeleccionado.monitor = this.arregloMonitor[0];

        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }

  public obtenerRatonesBackend(): any {
    this.subscription = this.ratonService
      .obtenerRaton()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          respuesta.unshift(new Raton(0, "", "Seleccione un ratón"));
          this.arregloRaton = respuesta;
          this.pcSeleccionado.raton = this.arregloRaton[0];
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }
  public obtenerTecladosBackend(): any {
    this.subscription = this.tecladoService
      .obtenerTeclado()
      .pipe(
        map((respuesta) => {
          console.log(respuesta);
          respuesta.unshift(new Teclado(0, "", "Seleccione un teclado"))
          this.arregloTeclado = respuesta;
          this.pcSeleccionado.teclado = this.arregloTeclado[0];
        }),
        finalize(() => {
          this.cargaFinalizada = true;
        })
      ).subscribe(ObservadoresAny);
  }

  public operaciones(form: NgForm, event: any): void {
    const accion = event.submitter.id;

    switch (accion) {
      case "btnCrearPc":
        this.crearPc();
        break;
      case "btnActualizarPc":
        this.actualizarPc(form);
        break;
    }
  }

  public crearPc(): void {
    if (this.validarCamposPc()) {
      this.subscription = this.computadoraService.crearComputador(this.pcSeleccionado).pipe(
        map((respuesta) => {
          mostrarMensaje("success", "Agregado con exito", "El Computador " + this.pcSeleccionado.nombre, this.toastr);
          this.computadoraService.notificarActualizacionLista();
        }),
        catchError((err) => {
          mostrarMensaje("error", "Falló la creación del Pc", "Advertencia", this.toastr);
          throw err;
        })
      ).subscribe(ObservadoresAny);
      this.resetPc();

    } else {
      mostrarMensaje("error", "No se pueden crear el computador<br />con campos vacíos", "Advertencia", this.toastr);
    }
  }

  public actualizarPc(form: NgForm): void { //REVISAR PERSISTENCIA COMBOS TECLADO - RATON
    if (this.validarCamposPc()) {
      const miIdComputadora = this.pcSeleccionado.idComputadora;
      const miNombre = this.pcSeleccionado.nombre;
      const miMonitor = this.pcSeleccionado.monitor;
      const miTeclado = this.pcSeleccionado.teclado;
      const miRaton = this.pcSeleccionado.raton;
      const miPublicoFotoComputadora = this.pcSeleccionado.publicoFotoComputadora;
      const miBase64Computadora = this.pcSeleccionado.base64Computadora;
      const miPrecio = this.pcSeleccionado.precio;
      const newEdit = new Computador(miIdComputadora, miNombre, miMonitor, miTeclado, miRaton, miPublicoFotoComputadora, miBase64Computadora, miPrecio);
      this.subscription = this.computadoraService.actualizarComputador(newEdit).pipe(
        map((respuesta) => {
          mostrarMensaje("success", "Editado con exito", "El Computador " + this.pcSeleccionado.nombre, this.toastr);
          this.computadoraService.notificarActualizacionLista();
          this.resetPc();
          form.resetForm();
        }),
        catchError((err) => {
          mostrarMensaje('error', 'Falló la actualización del periferico', 'Error', this.toastr);
          form.reset();
          throw err;
        })
      ).subscribe(ObservadoresAny);

    } else {
      mostrarMensaje("warning", "No se puede actualizar el computador<br />con campos vacíos", "Advertencia", this.toastr);

    }
  }
  //Validación de campos
  public validarCamposPc(): boolean {
    var bandera = true;
    if (this.pcSeleccionado.nombre == "" || this.pcSeleccionado.monitor.idMonitor == 0 
    || this.pcSeleccionado.raton.id == 0 || this.pcSeleccionado.teclado.id == 0 
    || this.pcSeleccionado.publicoFotoComputadora == "") {
      bandera = false;
    }
    return bandera;
  }

  // Manejo input de la imagen
  // ***********************************************************************
  public seleccionarFoto(objeto: any): any {
    let caja = objeto.target.files[0]
    if (!caja || caja.length == 0) {
      return;
    }
    if (caja.type.match(/image\/*/) == null) {
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(caja);
    reader.onload = () => {
      this.tmpBase64 = reader.result;
      this.pcSeleccionado.publicoFotoComputadora = caja.name;
      this.pcSeleccionado.base64Computadora = this.tmpBase64;
    };
  }

  public resetPc(): void {
    this.misRutas.navigateByUrl("private/dash/computer");
    this.pcSeleccionado = globals.inicializarPc();
  }

  public cancelForm(form: NgForm): void {
    this.resetPc();
    form.resetForm();
    this.inicializarCombo();
  }
}
