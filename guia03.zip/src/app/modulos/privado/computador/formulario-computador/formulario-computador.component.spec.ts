import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormularioComputadorComponent } from './formulario-computador.component';

describe('FormularioComputadorComponent', () => {
  let component: FormularioComputadorComponent;
  let fixture: ComponentFixture<FormularioComputadorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FormularioComputadorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FormularioComputadorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
