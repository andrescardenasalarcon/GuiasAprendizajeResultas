import { Monitor } from "../modelos/monitor.model";
import { Raton } from "../modelos/raton.model";
import { Teclado } from "../modelos/teclado.model";
import { Computador } from "../modelos/computador.model";
import { Comprador } from '../modelos/comprador.model';
import { Orden } from '../modelos/orden.model';
import { MiSesion } from '../modelos/mi-sesion.model';


export function inicializarMonitor(): Monitor {
     return new Monitor(0, "", 0, "", "");
}

export function inicializarRaton(): Raton {
     return new Raton(0, "", "");
}
export function inicializarTeclado(): Teclado {
     return new Teclado(0, "", "");
}

export function inicializarPc(): Computador {
     return new Computador(0, "", inicializarMonitor(), inicializarRaton(), inicializarTeclado(), "", "", 0);
}

export function inicializarComprador(): Comprador {
     return new Comprador(0, "", "", "", "", "", "", "");
}

export function inicializarOrden(): Orden {
     return new Orden(0, inicializarPc(), inicializarComprador(), 0);
}

export function inicializarMiSesion(): MiSesion {
     return new MiSesion("", "", "", "1", "1", "");
}