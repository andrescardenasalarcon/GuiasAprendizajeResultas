export const API_URL: string = 'http://localhost:8080/';

export const API_MONITOR: string = API_URL + 'api/monitor';
export const API_TECLADO: string = API_URL + 'api/teclado';
export const API_RATON: string = API_URL + 'api/raton';
export const API_COMPUTADOR: string = API_URL + 'api/computador';
export const API_COMPRADOR: string = API_URL + 'api/comprador';
export const API_ORDEN: string = API_URL + 'api/orden';

export const API_INICIO_SESION: string = API_URL + 'api/public';
export const API_REGISTRO_SESION: string = API_URL + 'api/public';