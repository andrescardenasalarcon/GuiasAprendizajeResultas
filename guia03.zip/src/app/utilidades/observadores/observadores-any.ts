import { Observer } from "rxjs";

export const ObservadoresAny: Observer<any> = {
    next(res) {
        console.log(res);
    },
    error(err) {
        console.log(err);

    }, complete() {
        console.log("Operation completed");
    }
};