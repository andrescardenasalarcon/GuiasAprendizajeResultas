import { Routes } from "@angular/router";
import { ErrorPrivadoComponent } from "../../modulos/privado/error-privado/error-privado.component";


export const RUTAS_PRIVADAS: Routes = [
    { path: 'dash', loadChildren: () => import('../../modulos/privado/privado.module').then((m) => (m.PrivadoModule)) },

    { path: '', redirectTo: 'dash', pathMatch: 'full' },
    { path: '**', component: ErrorPrivadoComponent }

]