import { Routes } from "@angular/router"

export const RUTAS_PUBLICAS: Routes = [
    { path: 'public', loadChildren: () => import('../../modulos/publico/publico.module').then((p) => (p.PublicoModule)) },

    { path: '', redirectTo: 'public', pathMatch: 'full' }
]
