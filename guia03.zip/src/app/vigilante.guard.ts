import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { InicioSesionService } from './servicios/inicio-sesion.service';

@Injectable({
  providedIn: 'root',
})
export class vigilanteGuard {
  constructor(private iniciarSesionService: InicioSesionService, private router: Router) {
  }

  canActivate(): boolean {
    if (this.iniciarSesionService.verificarUsuario()) {
      return true;
    }
    this.router.navigate(['/public/home']);
    return false;
  }
};
