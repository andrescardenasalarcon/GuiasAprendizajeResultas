import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { Monitor } from '../modelos/monitor.model';
import * as miUrl from '../utilidades/dominios/uris';
 
@Injectable({
  providedIn: 'root'
})
export class MonitorService {
  public apiMonitor: string = miUrl.API_MONITOR;

  constructor(private http: HttpClient) { }

  public obtenerMonitor(): Observable<Monitor[]> {
    return this.http.get<Monitor[]>(this.apiMonitor + "/");
  }

  public buscarUnMonitor(codMonitor: string): Observable<Monitor> {
    const url = this.apiMonitor + "/" + codMonitor;
    return this.http.get<Monitor>(url);
  }

  public crearMonitor(objMonitor: Monitor): Observable<Monitor> {
    const url = this.apiMonitor + "/crearMonitor";
    return this.http.post<Monitor>(url, objMonitor);
  }

  public actualizarMonitor(objMonitor: Monitor): Observable<Monitor> {
    const url = this.apiMonitor + "/editarMonitor";
    return this.http.put<Monitor>(url, objMonitor);
  }

  public borrarMonitor(codMonitor: number): Observable<Monitor> {
    return this.http.delete<Monitor>(this.apiMonitor + "/" + codMonitor).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error)
      })
    )
  }

}

