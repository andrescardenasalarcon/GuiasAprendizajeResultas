
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as miUrl from '../utilidades/dominios/uris';
import * as globals from '../utilidades/inits';
import { jwtDecode } from 'jwt-decode';
import { MiSesion } from '../modelos/mi-sesion.model';
import { InicioSesion } from '../modelos/inicio-sesion.model';
import { RespuestaInicioSesion } from '../modelos/respuesta-inicio-sesion.model';

@Injectable({
  providedIn: 'root'
})
export class InicioSesionService {

  public apiInicioSesion: string = miUrl.API_INICIO_SESION;

  public objMiSesion: MiSesion;

  constructor(private http: HttpClient, private router: Router) {
    this.objMiSesion = globals.inicializarMiSesion();
  }

  public iniciarSesionBackend(objAcceso: InicioSesion): Observable<RespuestaInicioSesion> {
    return this.http.post<RespuestaInicioSesion>(this.apiInicioSesion + '/login', objAcceso);
  }

  public cerrarSesion(): void {
    localStorage.removeItem("token_backend");
    this.router.navigate(['/']);
  }
  
  public obtenerDatosSesion(): MiSesion {
    return this.objMiSesion;
  }

  //generar y verificar el usuario
  public verificarUsuario(): boolean {
    if (localStorage.getItem("token_backend")) {
      try {
        const miToken = String(localStorage.getItem("token_backend"))
        let objTemp: any = jwtDecode(miToken);

        this.objMiSesion.codSesion = objTemp.idUser;
        this.objMiSesion.nameUser = objTemp.user;
        this.objMiSesion.correoUsuario = objTemp.emailUser;
        this.objMiSesion.idPerfil = objTemp.idProfile;
        return true;
      } catch (error) {
        console.log("Tenemos un error: ", error);

      }
    }
    return false;
  }
}
