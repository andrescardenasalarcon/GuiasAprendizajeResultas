import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { Computador } from '../modelos/computador.model';
import * as miUrl from '../utilidades/dominios/uris';

@Injectable({
  providedIn: 'root'
})
export class ComputadorService {

  public apiComputador: string = miUrl.API_COMPUTADOR;
  private actualizarListaSubject = new Subject<void>();

  constructor(private http: HttpClient) { }

  public obtenerComputador(): Observable<Computador[]> {
    return this.http.get<Computador[]>(this.apiComputador + "/");
  }

  public buscarUnComputador(codComputador: string): Observable<Computador> {
    const url = this.apiComputador + "/" + codComputador;
    return this.http.get<Computador>(url);
  }

  public crearComputador(objComputador: Computador): Observable<Computador> {
    const url = this.apiComputador + "/crearPc";
    return this.http.post<Computador>(url, objComputador);
  }

  public actualizarComputador(objComputador: Computador): Observable<Computador> {
    const url = this.apiComputador + "/editarPc";
    console.log(objComputador);
    
    return this.http.put<Computador>(url, objComputador);
  }

  public borrarComputador(codComputador: number): Observable<Computador> {
    return this.http.delete<Computador>(this.apiComputador + "/" + codComputador);
  }
  public actualizarListaObservable(): Observable<void> {
    return this.actualizarListaSubject.asObservable();
  }

 public notificarActualizacionLista() {
    this.actualizarListaSubject.next();
  }
}
