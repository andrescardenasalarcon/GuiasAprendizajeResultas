import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Comprador } from '../modelos/comprador.model';
import * as miUrl from '../utilidades/dominios/uris';

@Injectable({
  providedIn: 'root'
})
export class CompradorService {

  public apiComprador: string = miUrl.API_COMPRADOR;

  constructor(private http: HttpClient) { }

  public obtenerComprador(): Observable<Comprador[]> {
    return this.http.get<Comprador[]>(this.apiComprador + "/");
  }

  public buscarUnComprador(codComprador: string): Observable<Comprador> {
    const url = this.apiComprador + "/" + codComprador;
    return this.http.get<Comprador>(url);
  }

  public crearComprador(objComprador: Comprador): Observable<Comprador> {
    const url = this.apiComprador + "/crearComprador";
    return this.http.post<Comprador>(url, objComprador);
  }

  public actualizarComprador(objComprador: Comprador): Observable<Comprador> {
    const url = this.apiComprador + "/editarComprador";
    return this.http.put<Comprador>(url, objComprador);
  }

  public borrarComprador(codComprador: number): Observable<Comprador> {
    return this.http.delete<Comprador>(this.apiComprador + "/" + codComprador);
  }

}
