import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, catchError, throwError } from 'rxjs';
import { Raton } from '../modelos/raton.model';
import * as miUrl from '../utilidades/dominios/uris';

@Injectable({
  providedIn: 'root'
})
export class RatonService {
  public apiRaton: string = miUrl.API_RATON;
  private actualizarListaSubject = new Subject<void>();

  constructor(private http: HttpClient) { }

  public obtenerRaton(): Observable<Raton[]> {
    return this.http.get<Raton[]>(this.apiRaton + "/");
  }

  public buscarUnRaton(codRaton: string): Observable<Raton> {
    const url = this.apiRaton + "/" + codRaton;
    return this.http.get<Raton>(url);
  }

  public crearRaton(objRaton: Raton): Observable<Raton> {
    const url = this.apiRaton + "/crearRaton";
    return this.http.post<Raton>(url, objRaton);
  }

  public actualizarRaton(objProduct: Raton): Observable<Raton> {
    const url = this.apiRaton + '/editarRaton';
    return this.http.put<Raton>(url, objProduct);
  }

  public borrarRaton(codRaton: number): Observable<Raton> {
    return this.http.delete<Raton>(this.apiRaton + "/" + codRaton).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error)
      })
    )

  }

  public actualizarListaObservable(): Observable<void> {
    return this.actualizarListaSubject.asObservable();
  }

 public notificarActualizacionLista() {
    this.actualizarListaSubject.next();
  }

}

