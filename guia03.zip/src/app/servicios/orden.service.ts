import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Orden } from '../modelos/orden.model';
import * as miUrl from '../utilidades/dominios/uris';

@Injectable({
  providedIn: 'root'
})
export class OrdenService {
  public apiOrden: string = miUrl.API_ORDEN;

  constructor(private http: HttpClient) { }

  public obtenerOrden(): Observable<Orden[]> {
    return this.http.get<Orden[]>(this.apiOrden + "/");
  }

  public buscarUnOrden(codOrden: string): Observable<Orden> {
    const url = this.apiOrden + "/" + codOrden;
    return this.http.get<Orden>(url);
  }

  public crearOrden(objOrden: Orden): Observable<Orden> {
    const url = this.apiOrden + "/crearOrden";
    return this.http.post<Orden>(url, objOrden);
  }

  public actualizarOrden(objOrden: Orden): Observable<Orden> {
    const url = this.apiOrden + "/editarOrden";
    return this.http.put<Orden>(url, objOrden);
  }

  public borrarOrden(codOrden: string): Observable<Orden> {
    return this.http.delete<Orden>(this.apiOrden + "/" + codOrden);
  }

}

