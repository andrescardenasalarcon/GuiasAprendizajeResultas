import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, catchError, throwError } from 'rxjs';
import { Teclado } from '../modelos/teclado.model';
import * as miUrl from '../utilidades/dominios/uris';

@Injectable({
  providedIn: 'root'
})
export class TecladoService {
  public apiTeclado: string = miUrl.API_TECLADO;
  private actualizarListaSubject = new Subject<void>();

  constructor(private http: HttpClient) { }

  public obtenerTeclado(): Observable<Teclado[]> {
    return this.http.get<Teclado[]>(this.apiTeclado + "/");
  }

  public buscarUnTeclado(codTeclado: string): Observable<Teclado> {
    const url = this.apiTeclado + "/" + codTeclado;
    return this.http.get<Teclado>(url);
  }

  public crearTeclado(objTeclado: Teclado): Observable<Teclado> {
    const url = this.apiTeclado + "/crearTeclado";
    return this.http.post<Teclado>(url, objTeclado);
  }

  public actualizarTeclado(objTeclado: Teclado): Observable<Teclado> {
    const url = this.apiTeclado + "/editarTeclado";
    return this.http.put<Teclado>(url, objTeclado);
  }

  public borrarTeclado(codTeclado: number): Observable<Teclado> {
    return this.http.delete<Teclado>(this.apiTeclado + "/" + codTeclado).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error)
      })
    )

  }

  public actualizarListaObservable(): Observable<void> {
    return this.actualizarListaSubject.asObservable();
  }

  public notificarActualizacionLista() {
    this.actualizarListaSubject.next();
  }
}

