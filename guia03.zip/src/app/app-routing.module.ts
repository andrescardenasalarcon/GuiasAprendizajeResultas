import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CuerpoPubComponent } from './modulos/contenedor/dashboardPublico/cuerpo-pub/cuerpo-pub.component';
import { RUTAS_PUBLICAS } from './utilidades/rutas/publicas-rutas';
import { ErrorPublicoComponent } from './modulos/publico/error-publico/error-publico.component';
import { CuerpoPrivComponent } from './modulos/contenedor/dashboardPrivado/cuerpo-priv/cuerpo-priv.component';
import { RUTAS_PRIVADAS } from './utilidades/rutas/privadas-rutas';
import { vigilanteGuard } from './vigilante.guard';

const routes: Routes = [

  //ESPACIO PARA RUTAS PUBLICAS
  { path: '', component: CuerpoPubComponent, children: RUTAS_PUBLICAS },

  //ESPACIO PARA RUTAS PRIVADAS + TOKEN
  {
    path: 'private', component: CuerpoPrivComponent, children: RUTAS_PRIVADAS,
    canActivate:[vigilanteGuard]
  },

  { path: '**', component: ErrorPublicoComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
