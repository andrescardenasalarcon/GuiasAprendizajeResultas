export class RegistroSesion {
    public nombreUsuario?: string;
    public apellidoUsuario?: string;
    public fullName?: string
    public emailUser: string;
    public stateUser: string;
    public idProfile: string;
    public password: string;
    public rePassword?: string;

    constructor(nombreCompleto: string, correo: string, contra: string,) {
        this.fullName = nombreCompleto;
        this.emailUser = correo;
        this.stateUser = '1';
        this.idProfile = '2';
        this.password = contra;
    }

}
