export interface  DispositivoEntrada {
    dispositivoEntrada: string;
    marca: string;
    
    toString(): string;

}