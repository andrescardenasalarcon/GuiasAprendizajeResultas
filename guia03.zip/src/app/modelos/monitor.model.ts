export class Monitor {
    public idMonitor: number;
    public marca: string;
    public tamanno: number;
    public fotoPublicaMonitor: string;
    public base64Monitor: string;

    constructor(idRaton: number, marca: string, tamanno: number, fpm: string, base64: string) {
        this.idMonitor = idRaton;
        this.marca = marca;
        this.tamanno = tamanno;
        this.fotoPublicaMonitor = fpm;
        this.base64Monitor = base64;

    }

    static fromJson(json: Monitor): Monitor {
        return new Monitor(
            json.idMonitor,
            json.marca,
            json.tamanno,
            json.fotoPublicaMonitor,
            json.base64Monitor
        );
    }

    public toString(): string {
        return `Marca: ${this.marca}, Tamaño: ${this.tamanno}''`;
    }

}