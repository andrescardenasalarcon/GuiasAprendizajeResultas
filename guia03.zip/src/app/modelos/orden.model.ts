import { Comprador } from "./comprador.model";
import { Computador } from "./computador.model";

export class Orden {
    public idOrden: number;
    public computadoras: Computador;
    public comprador: Comprador;
    public cantidad: number;

    constructor(idOrden: number, computadoras: Computador, comprador: Comprador, cantidad: number) {
        this.idOrden = idOrden;
        this.computadoras = computadoras;
        this.comprador = comprador;
        this.cantidad = cantidad;
    }

    public getTotal(): string {
        const IVA = 0.19;
        const precioPc: number = this.computadoras.precio;
        return (((precioPc * (IVA + 1)) * this.cantidad)).toFixed(2);
    }

    static fromJson(json: Orden): Orden {
        return new Orden(
            json.idOrden,
            json.computadoras,
            json.comprador,
            json.cantidad
        );
    }

    public toString(): string {
        return `id: ${this.idOrden}, comprador: ${this.comprador.toString()},
        computadoras: ${this.computadoras.toString()}, cantidad: ${this.cantidad}`
    }
}