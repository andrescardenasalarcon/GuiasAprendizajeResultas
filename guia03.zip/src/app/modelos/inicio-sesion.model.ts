export class InicioSesion {

    public emailUser: string;
    public password: string;

    constructor(correo: string, clave: string) {
        this.emailUser = correo;
        this.password = clave;
    }

}
