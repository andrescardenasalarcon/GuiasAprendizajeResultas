import { Monitor } from "./monitor.model";
import { Raton } from "./raton.model";
import { Teclado } from "./teclado.model";

export class Computador {
    public idComputadora: number;
    public nombre: string;
    public monitor: Monitor;
    public teclado: Teclado;
    public raton: Raton;
    public publicoFotoComputadora: string;
    public base64Computadora: string;
    public precio: number;

    constructor(idComputadora: number, nombre: string, monitor: Monitor, teclado: Teclado, raton: Raton, pubFoto: string, base64: string, precio: number) {
        this.idComputadora = idComputadora;
        this.nombre = nombre;
        this.monitor = monitor;
        this.teclado = teclado;
        this.raton = raton;
        this.publicoFotoComputadora = pubFoto;
        this.base64Computadora = base64;
        this.precio = precio;
    }

    public toString(): string {
        return `Nombre: ${this.nombre}, Monitor: ${this.monitor}, Raton: ${this.raton.toString()}, Teclado: ${this.teclado.toString()}`;
    }

    static fromJson(json: Computador): Computador {
        const monitor = Monitor.fromJson(JSON.parse(json.monitor.toString()));
        const teclado = Teclado.fromJson(JSON.parse(json.teclado.toString()));
        const raton = Raton.fromJson(JSON.parse(json.raton.toString()));

        return new Computador(
            json.idComputadora,
            json.nombre,
            monitor,
            teclado,
            raton,
            json.publicoFotoComputadora,
            json.base64Computadora,
            json.precio
        );

    }

}