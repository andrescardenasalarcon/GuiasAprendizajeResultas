import { Persona } from "./persona.interface";

export class Comprador implements Persona {
    public idComprador: number;
    public primerNombre: string;
    public segundoNombre: string;
    public primerApellido: string;
    public segundoApellido: string;
    public documento: string;
    public nombreFoto: string;
    public base64Comprador: string;


    constructor(cod: number, primerNombre: string, segundoNombre: string, primerApellido: string, segundoApellido: string,
        documento: string, nombreFoto: string, fotobase64: string) {
        this.idComprador = cod;
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.documento = documento;
        this.nombreFoto = nombreFoto;
        this.base64Comprador = fotobase64;
    }

    public fullName(): string {
        return `${this.primerNombre} ${this.segundoNombre} ${this.primerApellido} ${this.segundoApellido}`
    }

    static fromJson(json: Comprador): Comprador {
        return new Comprador(
            json.idComprador,
            json.primerNombre,
            json.segundoNombre,
            json.primerApellido,
            json.segundoApellido,
            json.documento,
            json.nombreFoto,
            json.base64Comprador
        );
    }

    public toString(): string {
        return `primerNombre ${this.primerNombre} segundoNombre ${this.segundoNombre} primerApellido 
        ${this.primerApellido} segundoApellido ${this.segundoApellido} documento ${this.documento}`
    }
}