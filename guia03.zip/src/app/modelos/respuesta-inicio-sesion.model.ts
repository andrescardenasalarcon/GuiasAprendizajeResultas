export class RespuestaInicioSesion {

    public tokenBackend: string;

    constructor(token: string) {
        this.tokenBackend = token;
    }
}
