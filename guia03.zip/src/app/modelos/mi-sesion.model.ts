export class MiSesion {
    public codSesion: string;
    public correoUsuario: string;
    public nameUser: string;
    public estadoUser: string;
    public idPerfil: string;
    public contraseña: string;

    constructor(cod: string, correoUsuario: string,nameUser: string, estadoUser: string, idPerfil: string, contra: string) {
        this.codSesion = cod;
        this.correoUsuario = correoUsuario;
        this.nameUser = nameUser;
        this.estadoUser = estadoUser;
        this.idPerfil = idPerfil;
        this.contraseña = contra;

    }

}
