import { DispositivoEntrada } from "./dispositivo-entrada.interface";

export class Raton implements DispositivoEntrada {
    public id: number;
    public dispositivoEntrada: string;
    public marca: string;

    constructor(id: number, marca: string, dispo: string) {
        this.id = id;
        this.marca = marca;
        this.dispositivoEntrada = dispo;
    }

    public toString(): string {
        return `Marca: ${this.marca}, Dispositivo Entrada: ${this.dispositivoEntrada}`;
    }

    static fromJson(json: Raton): Raton {
        return new Raton(
            json.id,
            json.dispositivoEntrada,
            json.marca
        );
    }
}