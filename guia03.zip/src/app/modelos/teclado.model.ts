import { DispositivoEntrada } from "./dispositivo-entrada.interface";


export class Teclado implements DispositivoEntrada {
    public id: number;
    public dispositivoEntrada: string;
    public marca: string;

    constructor(id: number, dispo: string, marca: string) {
        this.id = id;
        this.dispositivoEntrada = dispo;
        this.marca = marca;
    }

    public toString(): string {
        return `Marca: ${this.marca}, Dispositivo Entrada: ${this.dispositivoEntrada}`;
    }

    static fromJson(json: Teclado): Teclado {
        return new Teclado(
            json.id,
            json.dispositivoEntrada,
            json.marca
        );

    }
}